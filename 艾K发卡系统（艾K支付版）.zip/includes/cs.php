<?php
date_default_timezone_set("PRC");
require("../mailer/class.phpmailer.php");
require("../mailer/class.smtp.php");
require("function.php");
echo sendmail('22814326@qq.com','这是标题','艾K码支付www.aikpay.cn','22814326@qq.com','cjtanltrweaabjje');
?>