<?php
/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496
 */

//www.aikpay.cn
function authcode($string, $operation = 'DECODE', $key = '', $expiry = 0) {
	$ckey_length = 4;
	$key = md5($key ? $key : ENCRYPT_KEY);
	$keya = md5(substr($key, 0, 16));
	$keyb = md5(substr($key, 16, 16));
	$keyc = $ckey_length ? ($operation == 'DECODE' ? substr($string, 0, $ckey_length): substr(md5(microtime()), -$ckey_length)) : '';
	$cryptkey = $keya.md5($keya.$keyc);
	$key_length = strlen($cryptkey);
	$string = $operation == 'DECODE' ? base64_decode(substr($string, $ckey_length)) : sprintf('%010d', $expiry ? $expiry + time() : 0).substr(md5($string.$keyb), 0, 16).$string;
	$string_length = strlen($string);
	$result = '';
	$box = range(0, 255);
	$rndkey = array();
	for($i = 0; $i <= 255; $i++) {
		$rndkey[$i] = ord($cryptkey[$i % $key_length]);
	}
	for($j = $i = 0; $i < 256; $i++) {
		$j = ($j + $box[$i] + $rndkey[$i]) % 256;
		$tmp = $box[$i];
		$box[$i] = $box[$j];
		$box[$j] = $tmp;
	}
	for($a = $j = $i = 0; $i < $string_length; $i++) {
		$a = ($a + 1) % 256;
		$j = ($j + $box[$a]) % 256;
		$tmp = $box[$a];
		$box[$a] = $box[$j];
		$box[$j] = $tmp;
		$result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
	}
	if($operation == 'DECODE') {
		if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26).$keyb), 0, 16)) {
			return substr($result, 26);
		} else {
			return '';
		}
	} else {
		return $keyc.str_replace('=', '', base64_encode($result));
	}
}

//过滤函数
function daddslashes($string, $force = 0, $strip = FALSE) {
	!defined('MAGIC_QUOTES_GPC') && define('MAGIC_QUOTES_GPC', get_magic_quotes_gpc());
	if(!MAGIC_QUOTES_GPC || $force) {
		if(is_array($string)) {
			foreach($string as $key => $val) {
				$string[$key] = daddslashes($val, $force, $strip);
			}
		} else {
			$string = addslashes($strip ? stripslashes($string) : $string);
		}
	}
	return $string;
}

//商品状态
function getgoodsstate($state,$gid){
	if($state==0){
		$zt="<button class='btn btn-danger btn-xs' onclick='GoodsState1(".$gid.")'>已下架</button>";
	}else{
		$zt="<button class='btn btn-success btn-xs' onclick='GoodsState0(".$gid.")'>已上架</button>";
	}
	return $zt;
}

//卡密状态
function getkmstate($state){
	if($state==0){
		$zt="<font color='green'>未出售</font>";
	}else{
		$zt="<font color='red'>已出售</font>";
	}
	return $zt;
}

//支付状态
function getpaytate($state){
	if($state==1){
		$zt="<font color='green'>支付成功</font>";
	}else{
		$zt="<font color='red'>支付失败</font>";
	}
	return $zt;
}

//发送邮件
function sendmail($email,$title,$content,$mail_host,$mail_user,$mail_key){
	$mail = new PHPMailer(); //建立邮件发送类
	$mail->IsSMTP(); // 使用SMTP方式发送
	$mail->CharSet ="UTF-8";//设置编码，否则发送中文乱码
	$mail->Host = $mail_host; // 您的企业邮局域名
	$mail->SMTPAuth = true; // 启用SMTP验证功能
	$mail->Username = $mail_user; // 邮局用户名(请填写完整的email地址)
	$mail->Password = $mail_key; // 授权码
	$mail->From = $mail_user; //邮件发送者email地址
	$mail->FromName = "追忆流年";
	$mail->AddAddress($email, "追忆流年");//收件人地址，可以替换成任何想要接收邮件的email信箱,格式是AddAddress("收件人email","收件人姓名")
	$mail->IsHTML(true); // set email format to HTML //是否使用HTML格式
	$mail->Subject = "$title"; //邮件标题
	$mail->Body = $content; //邮件内容
	if($mail->Send()){
		return 'succ';
	}else{
		return 'error';
	}
}
?>