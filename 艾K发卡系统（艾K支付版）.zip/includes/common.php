<?php
/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496
 */
header("Content-type:text/html;charset=utf-8");
define('SYS_KEY', 'zyqq79520638');
session_start();
require_once('360safe/webscan_cache.php');
require_once('360safe/360webscan.php');
require_once("../conn.php");
$password_hash='!@#%!s!';
include "function.php";
include "member.php";
date_default_timezone_set("PRC");
require("../mailer/class.phpmailer.php");
require("../mailer/class.smtp.php");
date_default_timezone_set("PRC");
$goodsnum=$database->count("goods");
$kmnum=$database->count("kms");
$kmnuma=$database->count("kms",["state"=>1]);
$ordernum=$database->count("order");
$ordernuma=$database->count("order",["status"=>1]);
$webname=$database->get("config","webname");
?>