<?php
if(isset($_COOKIE["ylnfk_token"])){
	$token=authcode(daddslashes($_COOKIE['ylnfk_token']), 'DECODE', SYS_KEY);
	list($name, $sid) = explode("\t", $token);
	$userinfo=$database->get("config",["password","username"],["username"=>$name]);
	$session=md5($userinfo['username'].$userinfo['password'].$password_hash);
	if($session==$sid) {
		$login_admin=1;
	}else{
		$login_admin=0;
	}
}else{
	$login_admin=0;
}