/*****加载商品分类*****/
function getType(){
		  	var index = layer.load(2, {shade:[0.1,'#fff']});
		  	$.ajax({
				type : "POST",
				url : "ajax.php?act=getType",
				dataType : 'json',
				success : function(data) {					  
					  layer.close(index);
					  if(data.code == 0){
	                      layer.msg('数据加载成功');
						  $("#tid").html(data.msg);
	                  }else{
                          layer.msg(data.msg);
	                  }
				},
				error:function(data){
					layer.close(index);
					layer.msg('服务器错误');
					}
			});
		  	
}

/*****删除商品分类*****/
$("#deltype").click(function(){
var tid=$("select[name='tid']").val();
var index = layer.load(0, {shade: false});
$.ajax({
    url:'ajax.php?act=deltype',
    data:{tid:tid},
    type:'post',
    dataType:'json',
    success:function(data){
	  layer.close(index);
	  if(data.code == 0){
	 layer.msg('删除成功');
	 getType();
	  }else{
      layer.msg(data.msg);
	  }
    },
    error:function(data){
	 layer.close(index);
	 layer.msg('服务器错误！');
    }
});
});

/*****添加商品分类*****/
$("#addtype").click(function(){
var typename=$("input[name='typename']").val();
if(typename==''){layer.alert('分类名称不能为空！', { skin: 'layui-layer-molv',closeBtn: 0});return false;}
var index = layer.load(0, {shade: false});
$.ajax({
    url:'ajax.php?act=addtype',
    data:{typename:typename},
    type:'post',
    dataType:'json',
    success:function(data){
	  layer.close(index);
	  if(data.code == 0){
	 layer.msg('添加成功');
	 getType();
	  }else{
      layer.msg(data.msg);
	  }
    },
    error:function(data){
	 layer.close(index);
	 layer.msg('服务器错误！');
    }
});
});

/*****添加商品*****/
$("#addgoods").click(function(){
var tid=$("select[name='tid']").val();
var goodsname=$("input[name='goodsname']").val();
var goodsmoney=$("input[name='goodsmoney']").val();
var goodssort=$("input[name='goodssort']").val();
var goodsimg=$("input[name='goodsimg']").val();
var goodspresent=$("textarea[name='goodspresent']").val();
var goodsstate=$("select[name='goodsstate']").val();
if(goodsname=='' || goodsmoney=='' || goodssort==''){layer.alert('名称 价格 排序不能为空！', { skin: 'layui-layer-molv',closeBtn: 0});return false;}
var index = layer.load(0, {shade: false});
$.ajax({
    url:'ajax.php?act=addgoods',
    data:{tid:tid,goodsname:goodsname,goodsmoney:goodsmoney,goodssort:goodssort,goodsimg:goodsimg,goodspresent:goodspresent,goodsstate:goodsstate},
    type:'post',
    dataType:'json',
    success:function(data){
	  layer.close(index);
	  if(data.code == 0){
	 layer.msg('添加成功');
	  }else{
      layer.msg(data.msg);
	  }
    },
    error:function(data){
	 layer.close(index);
	 layer.msg('服务器错误！');
    }
});
});

/*****加载商品列表*****/
function getGoodslist(){
		  	var index = layer.load(2, {shade:[0.1,'#fff']});
		  	$.ajax({
				type : "POST",
				url : "ajax.php?act=getGoodslist",
				dataType : 'json',
				success : function(data) {					  
					  layer.close(index);
					  if(data.code == 0){
	                      layer.msg('数据加载成功');
						  $("#glid").html(data.msg);
						  $("#glbtn").html(data.msg2);
	                  }else{
                          layer.msg(data.msg);
	                  }
				},
				error:function(data){
					layer.close(index);
					layer.msg('服务器错误');
					}
			});
		  	
}

/*****商品列表上一页操作*****/
function goodsbtn1(p1){
		var index = layer.load(0, {shade: false});
			$.ajax({
				url:'ajax.php?act=getGoodslist',
				data:{p:p1},
				type:'post',
				dataType:'json',
				success : function(data) {					  
					  layer.close(index);
					  if(data.code == 0){
	                      layer.msg('数据加载成功');
						  $("#glid").html(data.msg);
						  $("#glbtn").html(data.msg2);
	                  }else{
                          layer.msg(data.msg);
	                  }
				},
				error:function(data){
					layer.close(index);
					layer.msg('服务器错误！');
				}
			});
	}
	
/*****商品列表下一页操作*****/
function goodsbtn2(p2){
		var index = layer.load(0, {shade: false});
			$.ajax({
				url:'ajax.php?act=getGoodslist',
				data:{p:p2},
				type:'post',
				dataType:'json',
				success : function(data) {					  
					  layer.close(index);
					  if(data.code == 0){
	                      layer.msg('数据加载成功');
						  $("#glid").html(data.msg);
						  $("#glbtn").html(data.msg2);
	                  }else{
                          layer.msg(data.msg);
	                  }
				},
				error:function(data){
					layer.close(index);
					layer.msg('服务器错误！');
				}
			});
	}
	
/*****上架商品*****/
function GoodsState1(gid){
		var index = layer.load(0, {shade: false});
			$.ajax({
				url:'ajax.php?act=GoodsState1',
				data:{gid:gid},
				type:'post',
				dataType:'json',
				success : function(data) {					  
					  layer.close(index);
					  if(data.code == 0){
	                      layer.msg('上架成功');
						   getGoodslist();
	                  }else{
                          layer.msg(data.msg);
	                  }
				},
				error:function(data){
					layer.close(index);
					layer.msg('服务器错误！');
				}
			});
	}
	
/*****下架商品*****/
function GoodsState0(gid){
		var index = layer.load(0, {shade: false});
			$.ajax({
				url:'ajax.php?act=GoodsState0',
				data:{gid:gid},
				type:'post',
				dataType:'json',
				success : function(data) {					  
					  layer.close(index);
					  if(data.code == 0){
	                      layer.msg('下架成功');
						   getGoodslist();
	                  }else{
                          layer.msg(data.msg);
	                  }
				},
				error:function(data){
					layer.close(index);
					layer.msg('服务器错误！');
				}
			});
	}
		
/*****删除商品*****/
function DelGoods(gid){
	layer.confirm('删除商品同时会删除所属的卡密！', {
  btn: ['删除','取消'] //按钮
}, function(){
 var index = layer.load(0, {shade: false});
			$.ajax({
				url:'ajax.php?act=DelGoods',
				data:{gid:gid},
				type:'post',
				dataType:'json',
				success : function(data) {					  
					  layer.close(index);
					  if(data.code == 0){
	                      layer.msg('删除成功');
						   getGoodslist();
	                  }else{
                          layer.msg(data.msg);
	                  }
				},
				error:function(data){
					layer.close(index);
					layer.msg('服务器错误！');
				}
			});
});
}

/*****获取指定商品信息*****/
function GoodsModal(gid){
	$('#GoodsModal').modal();
		var index = layer.load(2, {shade:[0.1,'#fff']});
			$.ajax({
				url:'ajax.php?act=GetGoodsInfo',
				data:{gid:gid},
				type:'post',
				dataType:'json',
				success : function(data) {	
				getType();
					  layer.close(index);
					  if(data.code == 0){
						   $("#GoodsInfo").html(data.msg);
	                  }else{
                          layer.msg(data.msg);
	                  }
				},
				error:function(data){
					layer.close(index);
					layer.msg('服务器错误！');
				}
			});
	}
	
/*****编辑商品*****/
$("#EditGoods").click(function(){
var tid=$("select[name='tid']").val();
var gid=$("input[name='gid']").val();
var goodsname=$("input[name='goodsname']").val();
var goodsmoney=$("input[name='goodsmoney']").val();
var goodssort=$("input[name='goodssort']").val();
var goodsimg=$("input[name='goodsimg']").val();
var goodspresent=$("textarea[name='goodspresent']").val();
if(goodsname=='' || goodsmoney=='' || goodssort==''){layer.alert('名称 价格 排序不能为空！', { skin: 'layui-layer-molv',closeBtn: 0});return false;}
var index = layer.load(0, {shade: false});
$.ajax({
    url:'ajax.php?act=EditGoods',
    data:{tid:tid,gid:gid,goodsname:goodsname,goodsmoney:goodsmoney,goodssort:goodssort,goodsimg:goodsimg,goodspresent:goodspresent},
    type:'post',
    dataType:'json',
    success:function(data){
	  layer.close(index);
	  if(data.code == 0){
	 layer.msg('编辑成功');
	  getGoodslist();
	  }else{
      layer.msg(data.msg);
	  }
    },
    error:function(data){
	 layer.close(index);
	 layer.msg('服务器错误！');
    }
});
});

/*****获取商品(gid,goodsname)*****/
function getGoods(){
		  	var index = layer.load(2, {shade:[0.1,'#fff']});
		  	$.ajax({
				type : "POST",
				url : "ajax.php?act=getGoods",
				dataType : 'json',
				success : function(data) {					  
					  layer.close(index);
					  if(data.code == 0){
	                      layer.msg('数据加载成功');
						  $("#gid").html(data.msg);
	                  }else{
                          layer.msg(data.msg);
	                  }
				},
				error:function(data){
					layer.close(index);
					layer.msg('服务器错误');
					}
			});
		  	
}

/*****导入卡密*****/
$("#addkm").click(function(){
var gid=$("select[name='gid']").val();
var km=$("textarea[name='km']").val();
if(km==''){layer.alert('卡密不能为空！', { skin: 'layui-layer-molv',closeBtn: 0});return false;}
var index = layer.load(0, {shade: false});
$.ajax({
    url:'ajax.php?act=addkm',
    data:{gid:gid,km:km},
    type:'post',
    dataType:'json',
    success:function(data){
	  layer.close(index);
	  if(data.code == 0){
	  layer.msg(data.msg);
	  }else{
      layer.msg(data.msg);
	  }
    },
    error:function(data){
	 layer.close(index);
	 layer.msg('服务器错误！');
    }
});
});

/*****加载卡密列表*****/
function getKmlist(){
		  	var index = layer.load(2, {shade:[0.1,'#fff']});
		  	$.ajax({
				type : "POST",
				url : "ajax.php?act=getKmlist",
				dataType : 'json',
				success : function(data) {					  
					  layer.close(index);
					  if(data.code == 0){
	                      layer.msg('数据加载成功');
						  $("#klid").html(data.msg);
						  $("#klbtn").html(data.msg2);
	                  }else{
                          layer.msg(data.msg);
	                  }
				},
				error:function(data){
					layer.close(index);
					layer.msg('服务器错误');
					}
			});
		  	
}

/*****卡密列表上一页操作*****/
function kmbtn1(p1){
		var index = layer.load(0, {shade: false});
			$.ajax({
				url:'ajax.php?act=getKmlist',
				data:{p:p1},
				type:'post',
				dataType:'json',
				success : function(data) {					  
					  layer.close(index);
					  if(data.code == 0){
	                      layer.msg('数据加载成功');
						  $("#klid").html(data.msg);
						  $("#klbtn").html(data.msg2);
	                  }else{
                          layer.msg(data.msg);
	                  }
				},
				error:function(data){
					layer.close(index);
					layer.msg('服务器错误！');
				}
			});
	}
	
/*****卡密列表下一页操作*****/
function kmbtn2(p2){
		var index = layer.load(0, {shade: false});
			$.ajax({
				url:'ajax.php?act=getKmlist',
				data:{p:p2},
				type:'post',
				dataType:'json',
				success : function(data) {					  
					  layer.close(index);
					  if(data.code == 0){
	                      layer.msg('数据加载成功');
						  $("#klid").html(data.msg);
						  $("#klbtn").html(data.msg2);
	                  }else{
                          layer.msg(data.msg);
	                  }
				},
				error:function(data){
					layer.close(index);
					layer.msg('服务器错误！');
				}
			});
	}
	
/*****删除卡密*****/
function DelKm(id){
	layer.confirm('确认删除此卡密吗？', {
  btn: ['删除','取消'] //按钮
}, function(){
 var index = layer.load(0, {shade: false});
			$.ajax({
				url:'ajax.php?act=DelKm',
				data:{id:id},
				type:'post',
				dataType:'json',
				success : function(data) {					  
					  layer.close(index);
					  if(data.code == 0){
	                      layer.msg('删除成功');
						   getKmlist();
	                  }else{
                          layer.msg(data.msg);
	                  }
				},
				error:function(data){
					layer.close(index);
					layer.msg('服务器错误！');
				}
			});
});
}

$("#logout").click(function(){
var index = layer.load(0, {shade: false});
$.ajax({
    url:'ajax.php?act=logout',
    data:{},
    type:'post',
    dataType:'json',
    success:function(data){
	  layer.close(index);
	  if(data.code == 0){
	 layer.msg('注销成功');
	setTimeout(function(){
  window.location.href=""}, 3000);
	  }else{
      layer.msg(data.msg);
	  }
    },
    error:function(data){
	 layer.close(index);
	 layer.msg('服务器错误！');
    }
});
});

/*****加载订单列表*****/
function getOrderlist(){
		  	var index = layer.load(2, {shade:[0.1,'#fff']});
		  	$.ajax({
				type : "POST",
				url : "ajax.php?act=getOrderlist",
				dataType : 'json',
				success : function(data) {					  
					  layer.close(index);
					  if(data.code == 0){
	                      layer.msg('数据加载成功');
						  $("#olid").html(data.msg);
						  $("#olbtn").html(data.msg2);
	                  }else{
                          layer.msg(data.msg);
	                  }
				},
				error:function(data){
					layer.close(index);
					layer.msg('服务器错误');
					}
			});
		  	
}

/*****订单列表上一页操作*****/
function orderbtn1(p1){
		var index = layer.load(0, {shade: false});
			$.ajax({
				url:'ajax.php?act=getOrderlist',
				data:{p:p1},
				type:'post',
				dataType:'json',
				success : function(data) {					  
					  layer.close(index);
					  if(data.code == 0){
	                      layer.msg('数据加载成功');
						  $("#olid").html(data.msg);
						  $("#olbtn").html(data.msg2);
	                  }else{
                          layer.msg(data.msg);
	                  }
				},
				error:function(data){
					layer.close(index);
					layer.msg('服务器错误！');
				}
			});
	}
	
/*****订单列表下一页操作*****/
function orderbtn2(p2){
		var index = layer.load(0, {shade: false});
			$.ajax({
				url:'ajax.php?act=getOrderlist',
				data:{p:p2},
				type:'post',
				dataType:'json',
				success : function(data) {					  
					  layer.close(index);
					  if(data.code == 0){
	                      layer.msg('数据加载成功');
						  $("#olid").html(data.msg);
						  $("#olbtn").html(data.msg2);
	                  }else{
                          layer.msg(data.msg);
	                  }
				},
				error:function(data){
					layer.close(index);
					layer.msg('服务器错误！');
				}
			});
	}
	
	/*****删除卡密*****/
function DelOrder(id){
	layer.confirm('确认删除此订单吗？<br>tips:删除订单将导致所关联的信息无法查询！', {
  btn: ['删除','取消'] //按钮
}, function(){
 var index = layer.load(0, {shade: false});
			$.ajax({
				url:'ajax.php?act=DelOrder',
				data:{id:id},
				type:'post',
				dataType:'json',
				success : function(data) {					  
					  layer.close(index);
					  if(data.code == 0){
	                      layer.msg('删除成功');
						   getOrderlist();
	                  }else{
                          layer.msg(data.msg);
	                  }
				},
				error:function(data){
					layer.close(index);
					layer.msg('服务器错误！');
				}
			});
});
}

/*****修改管理员密码*****/
$("#xgmm").click(function(){
var pwd=$("input[name='pwd']").val();
var pwd1=$("input[name='pwd1']").val();
if(pwd=='' || pwd1==''){layer.alert('请确保每一项都不为空！', { skin: 'layui-layer-molv',closeBtn: 0});return false;}
var index = layer.load(0, {shade: false});
$.ajax({
    url:'ajax.php?act=xgmm',
    data:{pwd:pwd,pwd1:pwd1},
    type:'post',
    dataType:'json',
    success:function(data){
	  layer.close(index);
	  if(data.code == 0){
	 layer.msg('修改成功');
	  }else{
      layer.msg(data.msg);
	  }
    },
    error:function(data){
	 layer.close(index);
	 layer.msg('服务器错误！');
    }
});
});

/*****邮箱发送测试*****/
$("#sendmail").click(function(){
var email=$("input[name='email']").val();
if(email==''){layer.alert('发送邮箱地址不能为空！', { skin: 'layui-layer-molv',closeBtn: 0});return false;}
var index = layer.load(0, {shade: false});
$.ajax({
    url:'ajax.php?act=sendmail',
    data:{email:email},
    type:'post',
    dataType:'json',
    success:function(data){
	  layer.close(index);
	  if(data.code == 0){
	 layer.msg('发送成功');
	  }else{
      layer.msg(data.msg);
	  }
    },
    error:function(data){
	 layer.close(index);
	 layer.msg('服务器错误！');
    }
});
});

/*****邮箱配置*****/
$("#bcmail").click(function(){
var mail_host=$("input[name='mail_host']").val();
var mail_user=$("input[name='mail_user']").val();
var mail_key=$("input[name='mail_key']").val();
if(mail_host=='' || mail_user=='' || mail_key==''){layer.alert('请确保每一项都不为空！', { skin: 'layui-layer-molv',closeBtn: 0});return false;}
var index = layer.load(0, {shade: false});
$.ajax({
    url:'ajax.php?act=bcmail',
    data:{mail_host:mail_host,mail_user:mail_user,mail_key:mail_key},
    type:'post',
    dataType:'json',
    success:function(data){
	  layer.close(index);
	  if(data.code == 0){
	 layer.msg('保存成功');
	  }else{
      layer.msg(data.msg);
	  }
    },
    error:function(data){
	 layer.close(index);
	 layer.msg('服务器错误！');
    }
});
});

/*****优化数据表*****/
$("#yhsql").click(function(){
var index = layer.load(0, {shade: false});
$.ajax({
    url:'ajax.php?act=yhsql',
    type:'post',
    dataType:'json',
    success:function(data){
	  layer.close(index);
	  if(data.code == 0){
	 layer.msg('优化成功');
	  }else{
      layer.msg(data.msg);
	  }
    },
    error:function(data){
	 layer.close(index);
	 layer.msg('服务器错误！');
    }
});
});

/*****删除未支付订单*****/
$("#delorders").click(function(){
var index = layer.load(0, {shade: false});
$.ajax({
    url:'ajax.php?act=delorders',
    type:'post',
    dataType:'json',
    success:function(data){
	  layer.close(index);
	  if(data.code == 0){
	 layer.msg('删除成功');
	  }else{
      layer.msg(data.msg);
	  }
    },
    error:function(data){
	 layer.close(index);
	 layer.msg('服务器错误！');
    }
});
});

/*****批量删除卡密*****/
$("#delkms").click(function(){
var gid=$("select[name='gid']").val();
var lx=$("select[name='lx']").val();
if(gid=='请选择商品'||lx=='请选择类型'){layer.alert('请选择商品和类型！', { skin: 'layui-layer-molv',closeBtn: 0});return false;}
var index = layer.load(0, {shade: false});
$.ajax({
    url:'ajax.php?act=delkms',
	data:{gid:gid,lx:lx},
    type:'post',
    dataType:'json',
    success:function(data){
	  layer.close(index);
	  if(data.code == 0){
	 layer.msg('删除成功');
	  }else{
      layer.msg(data.msg);
	  }
    },
    error:function(data){
	 layer.close(index);
	 layer.msg('服务器错误！');
    }
});
});
	
/*****保存网站信息*****/
$("#bcwebinfo").click(function(){
var webname=$("input[name='webname']").val();
var webtitle=$("input[name='webtitle']").val();
var webkeywords=$("input[name='webkeywords']").val();
var webdescription=$("input[name='webdescription']").val();
var qq=$("input[name='qq']").val();
var notice=$("textarea[name='notice']").val();
var index = layer.load(0, {shade: false});
$.ajax({
    url:'ajax.php?act=bcwebinfo',
	data:{webname:webname,webtitle:webtitle,webkeywords:webkeywords,webdescription:webdescription,qq:qq,notice:notice},
    type:'post',
    dataType:'json',
    success:function(data){
	  layer.close(index);
	  if(data.code == 0){
	 layer.msg('保存成功');
	  }else{
      layer.msg(data.msg);
	  }
    },
    error:function(data){
	 layer.close(index);
	 layer.msg('服务器错误！');
    }
});
});
		
/*****保存支付配置*****/
$("#bcpay").click(function(){
var pay_host=$("input[name='pay_host']").val();
var pay_id=$("input[name='pay_id']").val();
var pay_key=$("input[name='pay_key']").val();
var index = layer.load(0, {shade: false});
$.ajax({
    url:'ajax.php?act=bcpay',
	data:{pay_host:pay_host,pay_id:pay_id,pay_key:pay_key},
    type:'post',
    dataType:'json',
    success:function(data){
	  layer.close(index);
	  if(data.code == 0){
	 layer.msg('保存成功');
	  }else{
      layer.msg(data.msg);
	  }
    },
    error:function(data){
	 layer.close(index);
	 layer.msg('服务器错误！');
    }
});
});
				