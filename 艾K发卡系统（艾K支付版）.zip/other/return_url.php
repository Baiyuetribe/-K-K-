<?php

/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496

 *************************页面功能说明*************************
 * 该页面可在本机电脑测试
 * 可放入HTML等美化页面的代码、商户业务逻辑程序代码
 * 该页面可以使用PHP开发工具调试，也可以使用写文本函数logResult，该函数已被默认关闭，见epay_notify_class.php中的函数verifyReturn
 */
date_default_timezone_set("PRC");
require_once('../includes/360safe/webscan_cache.php');
require_once('../includes/360safe/360webscan.php');
require_once("epay.config.php");
require_once("lib/epay_notify.class.php");
require("../mailer/class.phpmailer.php");
require("../mailer/class.smtp.php");
include "../includes/function.php";
$mail=$database->get("config",["mail_host","mail_user","mail_key"]);
?>
<!DOCTYPE HTML>
<html>
    <head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<script src="../assets/admin/js/jquery.js"></script>
	 <script src="../assets/layer/layer.js"></script>
<?php
//计算得出通知验证结果
$alipayNotify = new AlipayNotify($alipay_config);
$verify_result = $alipayNotify->verifyReturn();
if($verify_result) {//验证成功
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//请在这里加上商户的业务逻辑程序代码
	
	//——请根据您的业务逻辑来编写程序（以下代码仅作参考）——
    //获取支付宝的通知返回参数，可参考技术文档中页面跳转同步通知参数列表

	//商户订单号

	$out_trade_no = $_GET['out_trade_no'];

	//支付宝交易号

	$trade_no = $_GET['trade_no'];

	//交易状态
	$trade_status = $_GET['trade_status'];

	//支付方式
	$type = $_GET['type'];

    $getorder=$database->get("order","*",["order_number"=>$out_trade_no]);
    if($_GET['trade_status'] == 'TRADE_SUCCESS' && $getorder["status"]==0) {
	    $paytime=date("Y-m-d H:i:s");
		$uporder=$database->update("order",["status"=>1,"paytime"=>$paytime],["order_number"=>"$out_trade_no"]);
        $selltime=date("Y-m-d H:i:s");	
		$contactway=$getorder['contactway'];
		$num=$getorder['num'];
        $gid=$getorder['gid'];
		$upkms=$database->query("UPDATE ylnfk_kms SET selltime='$selltime',order_number='$out_trade_no',contactway='$contactway',state=1  WHERE gid=$gid and state=0  order by id limit $num")->fetchAll();
		$kms=$database->select("kms",["km"],["order_number"=>"$out_trade_no"]);
		foreach($kms as $km)
		{
		   $kminfo.="<font color='red'>".$km['km']."</font><br>";
		}
		$kminfo='您的商品购买成功<br>卡密信息如下(一行一个) <br>'.$kminfo.'<br>想了解更多信息请前往网站查询哦！';
		sendmail($contactway,'购买成功！',$kminfo,$mail['mail_host'],$mail['mail_user'],$mail['mail_key']);
		echo"<script>
			layer.alert('商品购买成功！<br>订单号：".$out_trade_no."', {
		  skin: 'layui-layer-molv'
		  ,closeBtn: 0
		  ,icon:6
		}, function(){
		 window.location.href='../query.php?content=".$out_trade_no."'
		});
	</script>";
    }
    else {
		  echo"<script>
			layer.alert('此订单已处理！<br>订单号：".$out_trade_no."', {
		  skin: 'layui-layer-molv'
		  ,closeBtn: 0
		  ,icon:6
		}, function(){
		 window.location.href='../index.php'
		});
	</script>";
    }
}
else {
    //验证失败
    //如要调试，请看alipay_notify.php页面的verifyReturn函数
    echo"<script>
			layer.alert('订单验证失败！', {
		  skin: 'layui-layer-molv'
		  ,closeBtn: 0
		  ,icon:5
		}, function(){
		 window.location.href='../index.php'
		});
	</script>";
}
?>
        <title>追忆流年—在线支付</title>
	</head>
    <body>
    </body>
</html>