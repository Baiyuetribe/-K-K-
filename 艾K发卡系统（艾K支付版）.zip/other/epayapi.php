<?php
/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496
 */
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>艾K支付—订单支付</title>
</head>
     <script src="../assets/admin/js/jquery.js"></script>
	 <script src="../assets/layer/layer.js"></script>
<?php
/* *
 * 功能：即时到账交易接口接入页
 * 
 * 以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 * 该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
 */
require_once('../includes/360safe/webscan_cache.php');
require_once('../includes/360safe/360webscan.php');
require_once("epay.config.php");
require_once("lib/epay_submit.class.php");
include "../includes/function.php";
if(empty($_GET['order_number'])){
	exit("<script>
	layer.alert('商品订单号为空！', {
  skin: 'layui-layer-molv'
  ,closeBtn: 0
  ,icon:5
}, function(){
 window.location.href='../index.php'
});
	</script>");
}
$order_number=daddslashes($_GET['order_number']);

/**************************请求参数**************************/
        $domain='http://'.$_SERVER['HTTP_HOST'].'/other/';
        $notify_url = $domain.'notify_url.php';
        //需http://格式的完整路径，不能加?id=123这类自定义参数

        //页面跳转同步通知页面路径
        $return_url = $domain.'return_url.php';
        //需http://格式的完整路径，不能加?id=123这类自定义参数，不能写成http://localhost/

		$get=$database->get("order","*",["order_number"=>"$order_number"]);
		if(!$get){
			exit("<script>
	layer.alert('订单信息查询失败！', {
  skin: 'layui-layer-molv'
  ,closeBtn: 0
  ,icon:5
}, function(){
 window.location.href='../index.php'
});
	</script>");
		}
        //商户订单号
        $out_trade_no = $get['order_number'];
        //商户网站订单系统中唯一订单号，必填


		//支付方式
        $type = $get['type'];
        //商品名称
        $name = $get['goodsname'];
		//付款金额
        $money = $get['money'];
		//站点名称
        $sitename = '追忆流年';
        //必填

        //订单描述


/************************************************************/

//构造要请求的参数数组，无需改动
$parameter = array(
		"pid" => trim($alipay_config['partner']),
		"type" => $type,
		"notify_url"	=> $notify_url,
		"return_url"	=> $return_url,
		"out_trade_no"	=> $out_trade_no,
		"name"	=> $name,
		"money"	=> $money,
		"sitename"	=> $sitename
);

//建立请求
$alipaySubmit = new AlipaySubmit($alipay_config);
$html_text = $alipaySubmit->buildRequestForm($parameter);
echo $html_text;

?>
</body>
</html>