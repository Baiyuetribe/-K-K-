<?php

/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496



 *************************页面功能说明*************************
 * 创建该页面文件时，请留心该页面文件中无任何HTML代码及空格。
 * 该页面不能在本机电脑测试，请到服务器上做测试。请确保外部可以访问该页面。
 * 该页面调试工具请使用写文本函数logResult，该函数已被默认关闭，见alipay_notify_class.php中的函数verifyNotify
 */
date_default_timezone_set("PRC");
require_once('../includes/360safe/webscan_cache.php');
require_once('../includes/360safe/360webscan.php');
require_once("epay.config.php");
require_once("lib/epay_notify.class.php");
//计算得出通知验证结果
$alipayNotify = new AlipayNotify($alipay_config);
$verify_result = $alipayNotify->verifyNotify();

if($verify_result) {//验证成功
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//请在这里加上商户的业务逻辑程序代

	
	//——请根据您的业务逻辑来编写程序（以下代码仅作参考）——
	
    //获取支付宝的通知返回参数，可参考技术文档中服务器异步通知参数列表
	
	//商户订单号

	$out_trade_no = $_GET['out_trade_no'];

	//彩虹易支付交易号

	$trade_no = $_GET['trade_no'];

	//交易状态
	$trade_status = $_GET['trade_status'];

	//支付方式
	$type = $_GET['type'];

     $getorder=$database->get("order","*",["order_number"=>$out_trade_no]);
	if ($_GET['trade_status'] == 'TRADE_SUCCESS'  && $getorder["status"]==0) {
		$paytime=date("Y-m-d H:i:s");
		$uporder=$database->update("order",["status"=>1,"paytime"=>$paytime],["order_number"=>"$out_trade_no"]);
        $selltime=date("Y-m-d H:i:s");	
		$contactway=$getorder['contactway'];
		$num=$getorder['num'];
        $gid=$getorder['gid'];
		$upkms=$database->query("UPDATE ylnfk_kms SET selltime='$selltime',order_number='$out_trade_no',contactway='$contactway',state=1  WHERE gid=$gid and state=0  order by id limit $num")->fetchAll();
    }

	//——请根据您的业务逻辑来编写程序（以上代码仅作参考）——
        
	echo "success";		//请不要修改或删除
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
else {
    //验证失败
    echo "fail";
}
?>