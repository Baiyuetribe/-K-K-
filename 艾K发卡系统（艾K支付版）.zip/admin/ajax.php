<?php
/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496
 */
?>
<?php
@header('Content-Type: application/json; charset=UTF-8');
include('../includes/common.php');
if($login_admin!=1){exit("<script language='javascript'>window.location.href='login.php';</script>");}
$act=isset($_GET['act'])?daddslashes($_GET['act']):null;
switch($act){
	case 'getType':
	$select = "<option>请选择分类</option>";
	$types=$database->select("type",["id","typename"]);
	foreach($types as $type)
    {
      $select.="<option value='".$type['id']."'>".$type['typename']."</option>";
    }
	  exit('{"code":0,"msg":"'.$select.'"}');
    break;
	case 'deltype':
	$tid=daddslashes($_POST['tid']);
	$del=$database->delete("type",["id"=>$tid]);
	if($del){
		exit('{"code":0,"msg":"succ"}');
	}else{
		exit('{"code":-1,"msg":"删除失败"}');
	}
	break;
	case 'addtype':
	$typename=daddslashes($_POST['typename']);
	if(empty($typename)){
		exit('{"code":-1,"msg":"分类名称为空"}');
	}
	$add=$database->insert("type",["typename"=>$typename]);
	if($add){
		exit('{"code":0,"msg":"succ"}');
	}else{
		exit('{"code":-1,"msg":"添加失败"}');
	}
	break;
	case 'addgoods':
	$tid=daddslashes($_POST['tid']);
    $goodsname=daddslashes($_POST['goodsname']);
	$goodsmoney=daddslashes($_POST['goodsmoney']);
	$goodssort=daddslashes($_POST['goodssort']);
	$goodsimg=daddslashes($_POST['goodsimg']);
	$goodspresent=daddslashes($_POST['goodspresent']);
	$goodsstate=daddslashes($_POST['goodsstate']);
	if(!is_numeric($tid)||strpos($tid,".")||$tid<0!==false){
       exit('{"code":-1,"msg":"请选择正确的分类"}');
    }
	if(!is_numeric($goodsstate)||strpos($goodsstate,".")!==false){
       exit('{"code":-1,"msg":"请选择正确的状态"}');
    }
	if(!is_numeric($goodssort)||strpos($goodssort,".")||$goodssort<0 !==false){
       exit('{"code":-1,"msg":"请输入正确的商品排序"}');
    }
	if($goodsname==''||$goodsmoney==''||$goodssort==''){
		exit('{"code":-1,"msg":"名称 价格 排序不能为空"}');
	}
	if(!is_numeric($goodsmoney)!==false){
		exit('{"code":-1,"msg":"价格格式不正确"}');
	}
	if($goodsmoney<=0){
		exit('{"code":-1,"msg":"价格不能小于0"}');
	}
	$check_sort=$database->get("goods",["goodssort"],["goodssort"=>$goodssort]);
	if($check_sort){
		exit('{"code":-1,"msg":"排序重复"}');
	}
	$goodsname=htmlspecialchars($goodsname);
	$add=$database->insert("goods",["tid"=>$tid,"goodsname"=>$goodsname,"goodsmoney"=>$goodsmoney,"goodssort"=>$goodssort,"goodsimg"=>$goodsimg,"goodspresent"=>$goodspresent,"goodsstate"=>$goodsstate]);
	if($add){
		exit('{"code":0,"msg":"succ"}');
	}else{
		exit('{"code":-1,"msg":"添加失败"}');
	}
	break;
	case 'getGoodslist':
	$tbody='暂无商品';
	//每页显示的数量
    $pagesize = 10;
	//确定页数 p 参数
    if(empty($_POST['p'])){
        $p=1;
    }else{
        $p=daddslashes($_POST['p']);
    }
    //计算总页数
    $endp = ceil($goodsnum/$pagesize);	
    //数据指针
     $offset = ($p-1)*$pagesize;
	 $tbodys = $database->query("SELECT * FROM ylnfk_goods where 1 order by goodssort+0 asc limit $offset,$pagesize")->fetchAll();
 $goodsinfo="";
	foreach($tbodys as $tbody)
    {
	   $kmnum=$database->count("kms",["gid"=>$tbody['gid']]);
	   $kmnum0=$database->count("kms",["gid"=>$tbody['gid'],"state"=>0]);
	   $typename=$database->get("type","typename",["id"=>$tbody['tid']]);
	   $goodsinfo.="<tr><td>#".$tbody['gid']."</td><td>".$tbody['goodsname']."</td><td>".$typename."</td><td>".$tbody['goodsmoney']."</td><td>".getgoodsstate($tbody['goodsstate'],$tbody['gid'])."</td><td>".$kmnum."/".$kmnum0."</td><td><button class='btn btn-info btn-xs' onclick='GoodsModal(".$tbody['gid'].")'><i class='icon-edit '></i></button> <button class='btn btn-danger btn-xs' onclick='DelGoods(".$tbody['gid'].")'><i class='icon-trash '></i></button></td></tr>";
    }
	if($p==1){
		$p1=$p;
	}else{
		$p1=$p-1;
	}
	if($p==$endp){
		$p2=$p;
	}else{
		$p2=$p+1;
	}
	$glbtn="<div class='btn-row'><div class='btn-group'><button class='btn btn-default' type='button' onclick='goodsbtn1(".$p1.")'>上一页</button><button class='btn btn-danger' type='button'>".$p."</button><button class='btn btn-default' type='button' onclick='goodsbtn2(".$p2.")'>下一页</button></div></div>";
	  exit('{"code":0,"msg":"'.$goodsinfo.'","msg2":"'.$glbtn.'"}');
	break;
	case 'GoodsState1':
	$gid=daddslashes($_POST['gid']);
	$update=$database->update("goods",["goodsstate"=>1],["gid"=>$gid]);
	if($update){
		exit('{"code":0,"msg":"succ"}');
	}else{
		exit('{"code":-1,"msg":"上架失败"}');
	}
	break;
	case 'GoodsState0':
	$gid=daddslashes($_POST['gid']);
	$update=$database->update("goods",["goodsstate"=>0],["gid"=>$gid]);
	if($update){
		exit('{"code":0,"msg":"succ"}');
	}else{
		exit('{"code":-1,"msg":"下架失败"}');
	}
	break;
	case 'DelGoods':
	$gid=daddslashes($_POST['gid']);
	$del=$database->delete("goods",["gid"=>$gid]);
	if($del){
		$del2=$database->delete("kms",["gid"=>$gid]);
		if($del2){
			exit('{"code":0,"msg":"succ"}');
		}else{
			exit('{"code":-1,"msg":"卡密删除失败"}');
		}
	}else{
		exit('{"code":-1,"msg":"删除失败"}');
	}
	break;
	case 'GetGoodsInfo':
	$gid=daddslashes($_POST['gid']);
	$get=$database->get("goods","*",["gid"=>$gid]);
	if($get){
		$GoodsInfo="<form role='form'><div class='form-group'><label for='name'>选择分类</label><select name='tid' id='tid' class='form-control'></select></div><div class='input-group m-bot15'><span class='input-group-addon'>商品ID</span><input type='text' class='form-control' name='gid' id='gid' value='".$get['gid']."' disabled></div><div class='input-group m-bot15'><span class='input-group-addon'>商品名称</span><input type='text' class='form-control' name='goodsname' id='goodsname' value='".$get['goodsname']."' placeholder='请输入商品名称'></div><div class='input-group m-bot15'><span class='input-group-addon'>商品价格</span><input type='text' class='form-control' name='goodsmoney' id='goodsmoney' value='".$get['goodsmoney']."' placeholder='请输入商品价格'></div><div class='input-group m-bot15'><span class='input-group-addon'>商品排序</span><input type='text' class='form-control' name='goodssort' id='goodssort' value='".$get['goodssort']."' placeholder='请输入正整数'></div><div class='well well-sm'>数字越小排序越靠前</div><div class='input-group m-bot15'><span class='input-group-addon'>商品图片</span><input type='text' class='form-control' name='goodsimg' id='goodsimg' value='".$get['goodsimg']."' placeholder='请输入图片完整url'></div><div class='form-group'><label for='name'>商品介绍</label><textarea class='form-control' rows='3' name='goodspresent' id='goodspresent' placeholder='请输入商品介绍'>".$get['goodspresent']."</textarea></div></form>";
		exit('{"code":0,"msg":"'.$GoodsInfo.'"}');
	}else{
		exit('{"code":-1,"msg":"商品信息获取失败"}');
	}
	break;
	case 'EditGoods':
	$tid=daddslashes($_POST['tid']);
	$gid=daddslashes($_POST['gid']);
    $goodsname=daddslashes($_POST['goodsname']);
	$goodsmoney=daddslashes($_POST['goodsmoney']);
	$goodssort=daddslashes($_POST['goodssort']);
	$goodsimg=daddslashes($_POST['goodsimg']);
	$goodspresent=daddslashes($_POST['goodspresent']);
	if(!is_numeric($tid)||strpos($tid,".")||$tid<0!==false){
       exit('{"code":-1,"msg":"请选择正确的分类"}');
    }
	if(!is_numeric($goodssort)||strpos($goodssort,".")||$goodssort<0 !==false){
       exit('{"code":-1,"msg":"请输入正确的商品排序"}');
    }
	if($goodsname==''||$goodsmoney==''||$goodssort==''){
		exit('{"code":-1,"msg":"名称 价格 排序不能为空"}');
	}
	if(!is_numeric($goodsmoney)!==false){
		exit('{"code":-1,"msg":"价格格式不正确"}');
	}
	if($goodsmoney<=0){
		exit('{"code":-1,"msg":"价格不能小于0"}');
	}
	$get=$database->get("goods","goodssort",["gid"=>$gid]);
	if($get['goodssort']!=$goodssort){
	$check_sort=$database->get("goods",["goodssort"],["goodssort"=>$goodssort]);
	if($check_sort){
		exit('{"code":-1,"msg":"排序重复"}');
	}
	}
	$update=$database->update("goods",["tid"=>$tid,"goodsname"=>$goodsname,"goodsmoney"=>$goodsmoney,"goodssort"=>$goodssort,"goodsimg"=>$goodsimg,"goodspresent"=>$goodspresent],["gid"=>$gid]);
	if($update){
		exit('{"code":0,"msg":"succ"}');
	}else{
		exit('{"code":-1,"msg":"编辑失败"}');
	}
	break;
	case 'getGoods':
	$select = "<option>请选择商品</option>";
	$goodss=$database->select("goods",["gid","goodsname"]);
	foreach($goodss as $goods)
    {
      $select.="<option value='".$goods['gid']."'>".$goods['goodsname']."</option>";
    }
	  exit('{"code":0,"msg":"'.$select.'"}');
    break;
	case 'deltype':
	$tid=daddslashes($_POST['tid']);
	$del=$database->delete("type",["id"=>$tid]);
	if($del){
		exit('{"code":0,"msg":"succ"}');
	}else{
		exit('{"code":-1,"msg":"删除失败"}');
	}
	break;
	case 'addkm':
	$gid=daddslashes($_POST['gid']);
	$km=daddslashes($_POST['km']);
	$num=0;
	if($gid==''||$km==''){
		exit('{"code":-1,"msg":"商品ID 卡密不能为空"}');
	}
	if(!is_numeric($gid)||strpos($gid,".")||$gid<0!==false){
       exit('{"code":-1,"msg":"请选择正确的商品"}');
    }
    $arr = explode("\n",$km);
    for($i = 0; $i <count($arr);$i++){
		$add = $database->query("insert into ylnfk_kms(gid,km,importtime) values({$gid},'{$arr[$i]}',now())")->fetchAll();
    }
		exit('{"code":0,"msg":"成功导入'.count($arr).'张卡密"}');
	break;
		case 'getKmlist':
	$tbody='暂无卡密';
	//每页显示的数量
    $pagesize = 10;
	//确定页数 p 参数
    if(empty($_POST['p'])){
        $p=1;
    }else{
        $p=daddslashes($_POST['p']);
    }
    //计算总页数
    $endp = ceil($kmnum/$pagesize);	
    //数据指针
     $offset = ($p-1)*$pagesize;
	 $tbodys = $database->query("SELECT * FROM ylnfk_kms where 1 order by id asc limit $offset,$pagesize")->fetchAll();
 $kminfo="";
	foreach($tbodys as $tbody)
       {
           	   $goodsname=$database->get("goods","goodsname",["gid"=>$tbody['gid']]);
	   $goodsname=$goodsname."[id:".$tbody['gid']."]";
	   if($tbody['selltime']==null){$selltime='NULL';}else{$selltime=$tbody['selltime'];}
	   if($tbody['order_number']==null){$order_number='NULL';}else{$order_number=$tbody['order_number'];}
	   if($tbody['contactway']==null){$contactway='NULL';}else{$contactway=$tbody['contactway'];}
            $kminfo.="<tr><td>#".$tbody['id']."</td><td>". $goodsname."</td><td>".$tbody['km']."</td><td><p>".$tbody['importtime']."</p><p>".$selltime."</p></td><td>".$order_number."</td><td>".$contactway."</td><td>".getkmstate($tbody['state'])."</td><td><button class='btn btn-danger btn-xs' onclick='DelKm(".$tbody['id'].")'><i class='icon-trash '></i></button></td></tr>";
       }
	if($p==1){
		$p1=$p;
	}else{
		$p1=$p-1;
	}
	if($p==$endp){
		$p2=$p;
	}else{
		$p2=$p+1;
	}
	$kmbtn="<div class='btn-row'><div class='btn-group'><button class='btn btn-default' type='button' onclick='kmbtn1(".$p1.")'>上一页</button><button class='btn btn-danger' type='button'>".$p."</button><button class='btn btn-default' type='button' onclick='kmbtn2(".$p2.")'>下一页</button></div></div>";
	  exit('{"code":0,"msg":"'.$kminfo.'","msg2":"'.$kmbtn.'"}');
	break;
	case 'DelKm':
	$id=daddslashes($_POST['id']);
	$del=$database->delete("kms",["id"=>$id]);
	if($del){
		exit('{"code":0,"msg":"succ"}');
	}else{
		exit('{"code":-1,"msg":"删除失败"}');
	}
	break;
	case 'getOrderlist':
	$tbody='暂无订单';
	//每页显示的数量
    $pagesize = 10;
	//确定页数 p 参数
    if(empty($_POST['p'])){
        $p=1;
    }else{
        $p=daddslashes($_POST['p']);
    }
    //计算总页数
    $endp = ceil($ordernum/$pagesize);	
    //数据指针
     $offset = ($p-1)*$pagesize;
	 $tbodys = $database->query("SELECT * FROM ylnfk_order where 1 order by id asc limit $offset,$pagesize")->fetchAll();
 $orderinfo="";
	foreach($tbodys as $tbody)
       {
	       if($tbody['paytime']==null){$paytime='NULL';}else{$paytime=$tbody['paytime'];}
		   $orderinfo.="<tr><td>#".$tbody['id']."</td><td>".$tbody['order_number']."</td><td>".$tbody['goodsname']."</td><td>".$tbody['money']."</td><td>".$tbody['num']."</td><td><p>".$tbody['createtime']."</p><p>".$paytime."</p></td><td>".$tbody['contactway']."</td><td>".getpaytate($tbody['status'])."</td><td><button class='btn btn-danger btn-xs' onclick='DelOrder(".$tbody['id'].")'><i class='icon-trash '></i></button></td></tr>";
       }
	if($p==1){
		$p1=$p;
	}else{
		$p1=$p-1;
	}
	if($p==$endp){
		$p2=$p;
	}else{
		$p2=$p+1;
	}
	$orderbtn="<div class='btn-row'><div class='btn-group'><button class='btn btn-default' type='button' onclick='orderbtn1(".$p1.")'>上一页</button><button class='btn btn-danger' type='button'>".$p."</button><button class='btn btn-default' type='button' onclick='orderbtn2(".$p2.")'>下一页</button></div></div>";
	  exit('{"code":0,"msg":"'.$orderinfo.'","msg2":"'.$orderbtn.'"}');
	break;
	case 'DelOrder':
	$id=daddslashes($_POST['id']);
	$del=$database->delete("order",["id"=>$id]);
	if($del){
		exit('{"code":0,"msg":"succ"}');
	}else{
		exit('{"code":-1,"msg":"删除失败"}');
	}
	break;
	case 'logout':
	setcookie('PHPSESSID','',time()-1,"/");
	setcookie('ylnfk_token','',time()-1,"/");
	$_SESSION=array();
    session_destroy();
	    exit('{"code":0,"msg":"succ"}');
	break;
	case'xgmm':
	$pwd=daddslashes($_POST['pwd']);
	$pwd1=daddslashes($_POST['pwd1']);
	if($database->has("config",["password"=>$pwd])){
		if($database->update("config",["password"=>$pwd1])){
			exit('{"code":0,"msg":"succ"}');
		}else{
			exit('{"code":-1,"msg":"修改失败"}');
		}
	}else{
		exit('{"code":-1,"msg":"旧密码错误"}');
	}
	break;
	case'sendmail':
	$email=daddslashes($_POST['email']);
	$mail=$database->get("config",["mail_host","mail_user","mail_key"]);
    if(sendmail($email,'测试邮件','<h2>忆流年发卡系统</h2><p>Author：追忆&追忆流年&忆流年</p><p>QQ：79520638</p><p>Date：2018/1/12</p>',$mail['mail_host'],$mail['mail_user'],$mail['mail_key'])=='succ'){
		exit('{"code":0,"msg":"succ"}');
	}else{
		exit('{"code":-1,"msg":"发送失败"}');
	}
	break;
	case'bcmail':
	$mail_host=daddslashes($_POST['mail_host']);
	$mail_user=daddslashes($_POST['mail_user']);
	$mail_key=daddslashes($_POST['mail_key']);
	if($database->update("config",["mail_host"=>$mail_host,"mail_user"=>$mail_user,"mail_key"=>$mail_key])){
		exit('{"code":0,"msg":"succ"}');
	}else{
		exit('{"code":-1,"msg":"保存失败"}');
	}
	break;
	case'yhsql':
	$database->query("OPTIMIZE TABLE ylnfk_goods ")->fetchAll();
	$database->query("OPTIMIZE TABLE ylnfk_kms ")->fetchAll();
	$database->query("OPTIMIZE TABLE ylnfk_order ")->fetchAll();
	$database->query("OPTIMIZE TABLE ylnfk_type ")->fetchAll();
	exit('{"code":0,"msg":"succ"}');
	case'delorders':
	if($database->delete("order",["status"=>0])){
		exit('{"code":0,"msg":"succ"}');
	}else{
		exit('{"code":-1,"msg":"优化失败"}');
	}
	break;
	case'delkms':
	$gid=daddslashes($_POST['gid']);
	$lx=daddslashes($_POST['lx']);
	switch($lx){
		case'0':
		    if($database->delete("kms",["gid"=>$gid,"state"=>1])){
				exit('{"code":0,"msg":"succ"}');
			}else{
				exit('{"code":-1,"msg":"删除失败"}');
			}
		break;
		case'1':
			 if($database->delete("kms",["gid"=>$gid])){
					exit('{"code":0,"msg":"succ"}');
				}else{
					exit('{"code":-1,"msg":"删除失败"}');
				}
		break;
		default:
	        exit('{"code":-1,"msg":"类型错误"}');
        break;
	}
	break;
	case'bcwebinfo':
	$webname=daddslashes($_POST['webname']);
	$webtitle=daddslashes($_POST['webtitle']);
	$webkeywords=daddslashes($_POST['webkeywords']);
	$webdescription=daddslashes($_POST['webdescription']);
	$qq=daddslashes($_POST['qq']);
	$notice=$_POST['notice'];
	if($database->update("config",["webname"=>$webname,"webtitle"=>$webtitle,"webkeywords"=>$webkeywords,"webdescription"=>$webdescription,"qq"=>$qq,"notice"=>$notice])){
		exit('{"code":0,"msg":"succ"}');
	}else{
		exit('{"code":-1,"msg":"保存失败"}');
	}
	break;
	case'bcpay':
	$pay_host=daddslashes($_POST['pay_host']);
	$pay_id=daddslashes($_POST['pay_id']);
	$pay_key=daddslashes($_POST['pay_key']);
	if($database->update("config",["pay_host"=>$pay_host,"pay_id"=>$pay_id,"pay_key"=>$pay_key])){
		exit('{"code":0,"msg":"succ"}');
	}else{
		exit('{"code":-1,"msg":"保存失败"}');
	}
	break;
	default:
	exit('{"code":-2,"msg":"No Act"}');
    break;
}