<?php
/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496
 */
?>
<?php
include('../includes/common.php');
if($login_admin!=1){exit("<script language='javascript'>window.location.href='login.php';</script>");}
$title='邮箱配置';
include('head.php');
$mail=$database->get("config",["mail_host","mail_user","mail_key"]);
?>
 <section id="main-content">
          <section class="wrapper">
            
              <div class="row state-overview">
			  
                   <div class="col-sm-8 col-sm-offset-2">
                      <div class="panel panel-primary">
    <div class="panel-heading">
        <h3 class="panel-title"><font color="#ffffff"><h4>邮箱配置</h4></font></h3>
    </div>
    <div class="panel-body">
        
<form role="form">
 <div class="input-group">
            <span class="input-group-addon">SMTP服务器</span>
            <input type="text" class="form-control" id="mail_host" name="mail_host" value="<?php echo $mail['mail_host'];?>">
        </div>
        <br>
<div class="input-group">
            <span class="input-group-addon">邮箱账号</span>
            <input type="text" class="form-control" id="mail_user" name="mail_user" value="<?php echo $mail['mail_user']; ?>">
        </div>
        <br>
<div class="input-group">
            <span class="input-group-addon">邮箱授权码</span>
            <input type="text" class="form-control" id="mail_key" name="mail_key" value="<?php echo $mail['mail_key']; ?>">
        </div>
        <br>
   <button id="bcmail" type="button" class="btn btn-info btn-block">确认保存</button> 
<br>   
<div class="input-group">
       <span class="input-group-addon">发送邮箱</span>
       <input type="text" class="form-control" id="email" name="email">
        </div>
        <br>
    <button id="sendmail" type="button" class="btn btn-default btn-block">发送测试</button>     
</form>
		
    </div>
</div>
                     
                   </div> 
             </div>
  
            
  </section>
   </section>

<?php
include('foot.php');
?>