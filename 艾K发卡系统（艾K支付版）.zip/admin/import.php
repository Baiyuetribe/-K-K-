<?php
/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496
 */
?>
<?php
include('../includes/common.php');
if($login_admin!=1){exit("<script language='javascript'>window.location.href='login.php';</script>");}
$title='导入卡密';
include('head.php');
?>
 <section id="main-content">
          <section class="wrapper">
            
              <div class="row state-overview">
			  
                   <div class="col-sm-8 col-sm-offset-2">
                      <div class="panel panel-primary">
    <div class="panel-heading">
        <h3 class="panel-title"><font color="#ffffff"><h4>导入卡密</h4></font></h3>
    </div>
    <div class="panel-body">
        
<form role="form">
  <div class="form-group">
    <label for="name">选择商品</label>
    <select name="gid" id="gid" class="form-control">
    </select>
  </div>
  	<div class="form-group">
    <label for="name">卡密(一行一个)</label>
    <textarea class="form-control" rows="5" name="km" id="km" placeholder="请输入卡密"></textarea>
    </div>
   <button id="addkm" type="button" class="btn btn-info btn-block">确认导入</button>                               
</form>
		
    </div>
</div>
                     
                   </div> 
             </div>
  
            
  </section>
   </section>

<?php
include('foot.php');
?>
<script>
getGoods();
</script>