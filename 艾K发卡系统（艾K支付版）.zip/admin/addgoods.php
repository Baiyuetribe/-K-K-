<?php
/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496
 */
?>
<?php
include('../includes/common.php');
if($login_admin!=1){exit("<script language='javascript'>window.location.href='login.php';</script>");}
$title='添加商品';
include('head.php');
?>
 <section id="main-content">
          <section class="wrapper">
            
              <div class="row state-overview">
			  
                   <div class="col-sm-8 col-sm-offset-2">
                      <div class="panel panel-primary">
    <div class="panel-heading">
        <h3 class="panel-title"><font color="#ffffff"><h4>添加商品</h4></font></h3>
    </div>
    <div class="panel-body">
        
<form role="form">
    <div class="form-group">
    <label for="name">选择分类</label>
    <select name="tid" id="tid" class="form-control">
    </select>
    </div>
    <div class="input-group m-bot15">
    <span class="input-group-addon">商品名称</span>
    <input type="text" class="form-control" name="goodsname" id="goodsname" placeholder="请输入商品名称">
	</div>
	<div class="input-group m-bot15">
    <span class="input-group-addon">商品价格</span>
    <input type="text" class="form-control" name="goodsmoney" id="goodsmoney" placeholder="请输入商品价格">
	</div>
	<div class="input-group m-bot15">
    <span class="input-group-addon">商品排序</span>
    <input type="text" class="form-control" name="goodssort" id="goodssort" placeholder="请输入正整数">
	</div>
	<div class="well well-sm">数字越小排序越靠前</div>
	<div class="input-group m-bot15">
    <span class="input-group-addon">商品图片</span>
    <input type="text" class="form-control" name="goodsimg" id="goodsimg" placeholder="请输入图片完整url">
	</div>
	<div class="form-group">
    <label for="name">商品介绍</label>
    <textarea class="form-control" rows="3" name="goodspresent" id="goodspresent" placeholder="请输入商品介绍"></textarea>
    </div>
    <div class="form-group">
    <label for="name" name="goodsstate" id="goodsstate">商品状态</label>
    <select class="form-control" name="goodsstate" id="goodsstate">
      <option value="1">上架</option>
      <option value="0">下架</option>
	</select>
    </div>
   <button id="addgoods" type="button" class="btn btn-info btn-block">添加商品</button>                               
</form>
		
    </div>
</div>
                     
                   </div> 
             </div>
  
            
  </section>
   </section>

<?php
include('foot.php');
?>
<script>
getType();
</script>