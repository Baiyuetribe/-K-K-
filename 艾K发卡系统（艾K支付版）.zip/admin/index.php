<?php
/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496
 */
?>
<?php
include('../includes/common.php');
if($login_admin!=1){exit("<script language='javascript'>window.location.href='login.php';</script>");}
$title='后台管理';
include('head.php');

?>

 
      <section id="main-content">
          <section class="wrapper">
              <!--state overview start-->
              <div class="row state-overview">
                  <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                          <div class="symbol red">
                              <i class="icon-tags"></i>
                          </div>
                          <div class="value">
                              <h1><?php echo $kmnum;?></h1>
                              <p>卡密总数</p>
                          </div>
                      </section>
                  </div>
				   <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                          <div class="symbol terques">
                               <i class="icon-tags"></i>
                          </div>
                          <div class="value">
                              <h1><?php echo $kmnuma;?></h1>
                              <p>已售卡密</p>
                          </div>
                      </section>
                  </div>
				   <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                          <div class="symbol blue">
                              <i class="icon-bar-chart"></i>
                          </div>
                          <div class="value">
                              <h1><?php echo $ordernum;?></h1>
                              <p>订单总数</p>
                          </div>
                      </section>
                  </div>
                  <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                          <div class="symbol yellow">
                              <i class="icon-shopping-cart"></i>
                          </div>
                          <div class="value">
                              <h1><?php echo $ordernuma;?></h1>
                              <p>完成订单</p>
                          </div>
                      </section>
                  </div>
              </div>
              <!--state overview end-->
<div class="row state-overview">
<div class="col-lg-6 col-sm-6">
<ul class="list-group">
    <li class="list-group-item">
        <span class="badge">艾K发卡系统 - 艾K支付版</span>
        程序名称
    </li>
	 <li class="list-group-item">
        <span class="badge">艾K</span>
        Author
    </li>
	 <li class="list-group-item">
        <span class="badge">22814326/505114496</span>
       QQ
    </li>
	 <li class="list-group-item">
        <span class="badge">2019/1/13</span>
        Date
    </li>
	<li class="list-group-item">艾K支付平台：www.aikpay.cn （支持对接易支付/码支付！）</li>
</ul>
</div>
</div>
            
  </section>
   </section>
   
<?php
include('foot.php');
?>
