<?php
/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496
 */
?>
<?php
include('../includes/common.php');
if($login_admin!=1){exit("<script language='javascript'>window.location.href='login.php';</script>");}
$title='分类管理';
include('head.php');
?>
 <section id="main-content">
          <section class="wrapper">
            
              <div class="row state-overview">
			  
                   <div class="col-sm-8 col-sm-offset-2">
                      <div class="panel panel-primary">
    <div class="panel-heading">
        <h3 class="panel-title"><font color="#ffffff"><h4>商品分类管理</h4></font></h3>
    </div>
    <div class="panel-body">
        
<form role="form">
  <div class="form-group">
    <label for="name">选择分类</label>
    <select name="tid" id="tid" class="form-control">
    </select>
  </div>
  <button id="deltype" type="button" class="btn btn-danger btn-block">删除分类</button>
  <hr>
    <div class="input-group m-bot15">
    <span class="input-group-addon">分类名称</span>
    <input type="text" class="form-control" name="typename" id="typename" placeholder="请输入分类名称">
	</div>
   <button id="addtype" type="button" class="btn btn-info btn-block">添加分类</button>                               
</form>
		
    </div>
</div>
                     
                   </div> 
             </div>
  
            
  </section>
   </section>

<?php
include('foot.php');
?>
<script>
getType();
</script>