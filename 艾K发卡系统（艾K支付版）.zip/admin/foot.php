<?php
/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496
 */
?>
    <!-- js placed at the end of the document so the pages load faster -->
    <script src="../assets/admin/js/jquery.js"></script>
    <script src="../assets/admin/js/jquery-1.8.3.min.js"></script>
    <script src="../assets/admin/js/bootstrap.min.js"></script>
    <script src="../assets/admin/js/jquery.scrollTo.min.js"></script>
    <script src="../assets/admin/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="../assets/admin/js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="../assets/admin/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="../assets/admin/js/owl.carousel.js" ></script>
    <script src="../assets/admin/js/jquery.customSelect.min.js" ></script>

    <!--common script for all pages-->
    <script src="../assets/admin/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="../assets/admin/js/sparkline-chart.js"></script>
    <script src="../assets/admin/js/easy-pie-chart.js"></script>
	 <script src="../assets/layer/layer.js"></script>
	 <script src="../assets/ylnfk_admin.js"></script>

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });
  </script>

  </body>
</html>
