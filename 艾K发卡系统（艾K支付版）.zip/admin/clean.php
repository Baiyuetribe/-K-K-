<?php
/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496
 */
?>
<?php
include('../includes/common.php');
if($login_admin!=1){exit("<script language='javascript'>window.location.href='login.php';</script>");}
$title='数据清理';
include('head.php');
?>
<section id="main-content">
<section class="wrapper">

<div class="row state-overview">
<div class="col-sm-8 col-sm-offset-2">
<div class="panel panel-primary">
<div class="panel-heading">
<h3 class="panel-title"><font color="#ffffff"><h4>删除卡密</h4></font></h3>
</div>
<div class="panel-body">
<form role="form">
<div class="form-group">
<label for="name">选择商品</label>
<select name="gid" id="gid" class="form-control"></select>
</div>
<div class="form-group">
<label for="name">删除类型</label>
<select name="lx" id="lx" class="form-control">
<option>请选择类型</option>
<option value='0'>已售卡密</option>
<option value='1'>全部卡密</option>
</select>
</div>
<button id="delkms" type="button" class="btn btn-danger btn-block">确认删除</button>                               
</form>
</div>
</div>
</div> 
</div>

<div class="row state-overview">
<div class="col-sm-8 col-sm-offset-2">
<div class="panel panel-primary">
<div class="panel-heading">
<h3 class="panel-title"><font color="#ffffff"><h4>删除订单</h4></font></h3>
</div>
<div class="panel-body">
<form role="form">
<button id="delorders" type="button" class="btn btn-danger btn-block">删除未支付订单</button>                               
</form>
</div>
</div>
</div> 
</div>

<div class="row state-overview">
<div class="col-sm-8 col-sm-offset-2">
<div class="panel panel-primary">
<div class="panel-heading">
<h3 class="panel-title"><font color="#ffffff"><h4>优化数据表</h4></font></h3>
</div>
<div class="panel-body">
<form role="form">
<button id="yhsql" type="button" class="btn btn-success btn-block">立即优化</button>                               
</form>
</div>
</div>
</div> 
</div>
</section>
</section>

<?php
include('foot.php');
?>
<script>
getGoods();
</script>