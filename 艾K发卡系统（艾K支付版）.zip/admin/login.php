<?php
/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496
 */
?>
<?php
@header('Content-Type: text/html; charset=UTF-8');
include("../includes/common.php");
$webinfo=$database->get("config",["webname","webtitle","webkeywords","webdescription"]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <meta name="keyword" content="FlatLab, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <meta name="keywords" content="<?php echo $webinfo['webkeywords'];?>" />
    <meta name="description" content="<?php echo $webinfo['webdescription'];?>">
    <title>后台登录|<?php echo $webinfo['webname']; ?></title>
    <!-- Bootstrap core CSS -->
    <link href="../assets/admin/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/admin/css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="../assets/admin/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="../assets/admin/css/style.css" rel="stylesheet">
    <link href="../assets/admin/css/style-responsive.css" rel="stylesheet" />
	<link rel="stylesheet" href="../assets/layui/css/layui.css"  media="all">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="../assets/admin/js/html5shiv.js"></script>
    <script src="../assets/admin/js/respond.min.js"></script>
    <![endif]-->
	<style>
body
  {
  background-color:#E0E0E0;
  }
</style>
</head>

  <body>

    <div class="container">

      <form class="form-signin">
        <h2 class="form-signin-heading">后台登录</h2>
        <div class="login-wrap">
		<div class="form-group has-success">
            <input type="text" class="form-control" name="name" id="name" placeholder="请输入账号">
		</div>
		<div class="form-group has-success">
            <input type="password" class="form-control"  name="pwd" id="pwd" placeholder="请输入密码">
		</div>
		   <button class="btn btn-lg btn-shadow btn-danger btn-block" type="button" id="login" style="margin: 8px auto";>立即登录</button>
        </div>

      </form>

    </div>
	
<script src="../assets/admin/js/jquery.js"></script>
<script src="../assets/layui/layui.js" charset="utf-8"></script>
<script>
layui.use(['layer'], function(){
layer = layui.layer
});
$("#login").click(function(){
if ($(this).attr("data-lock") === "true") return;
var name=$("input[name='name']").val();
var pwd=$("input[name='pwd']").val();
if(name=='' || pwd==''){layer.alert('请确保每一项都不为空！', { skin: 'layui-layer-molv',closeBtn: 0});return false;}
var index = layer.load(0, {shade: false});
$.ajax({
    url:'../ajax.php?act=login',
    data:{name:name,pwd:pwd},
    type:'post',
    dataType:'json',
    success:function(data){
	  layer.close(index);
	  if(data.code == 0){
	 layer.msg('登陆成功，等待跳转');
	setTimeout(function(){
  window.location.href="index.php";
  }, 3000);
	  }else{
      layer.msg(data.msg);
	  }
    },
    error:function(data){
	 layer.close(index);
	 layer.msg('服务器错误！');
    }
});
});
</script>
  </body>
</html>
