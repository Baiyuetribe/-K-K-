<?php
/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496
 */
?>
<?php
include('../includes/common.php');
if($login_admin!=1){exit("<script language='javascript'>window.location.href='login.php';</script>");}
$title='管理员配置';
include('head.php');
$username=$database->get("config","username");
?>
 <section id="main-content">
          <section class="wrapper">
            
              <div class="row state-overview">
			  
                   <div class="col-sm-8 col-sm-offset-2">
                      <div class="panel panel-primary">
    <div class="panel-heading">
        <h3 class="panel-title"><font color="#ffffff"><h4>修改密码</h4></font></h3>
    </div>
    <div class="panel-body">
        
<form role="form">
 <div class="input-group">
            <span class="input-group-addon">账号</span>
            <input type="text" class="form-control" value="<?php echo $username;?>"disabled>
        </div>
        <br>
<div class="input-group">
            <span class="input-group-addon">旧密码</span>
            <input type="text" class="form-control" id="pwd" name="pwd">
        </div>
        <br>
<div class="input-group">
            <span class="input-group-addon">新密码</span>
            <input type="text" class="form-control" id="pwd1" name="pwd1">
        </div>
        <br>
   <button id="xgmm" type="button" class="btn btn-info btn-block">确认修改</button>                               
</form>
		
    </div>
</div>
                     
                   </div> 
             </div>
  
            
  </section>
   </section>

<?php
include('foot.php');
?>