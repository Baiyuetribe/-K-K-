<?php
/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496
 */
?>
<?php
include('../includes/common.php');
if($login_admin!=1){exit("<script language='javascript'>window.location.href='login.php';</script>");}
$title='卡密列表';
include('head.php');
?>
 <section id="main-content">
          <section class="wrapper">
            
              <div class="row state-overview">
			  
                   <div class="col-sm-8 col-sm-offset-2">
                      <div class="panel panel-primary">
    <div class="panel-heading">
        <h3 class="panel-title"><font color="#ffffff"><h4>卡密列表</h4></font></h3>
    </div>
<div class="panel-body">
        
<div class="table-responsive">
	  <table class="table table-striped table-advance table-hover">
                              <thead>
                              <tr>
                                  <th>ID</th>
                                  <th>商品名字</th>
								  <th>卡密</th>
								  <th>导入时间/出售时间</th>
								  <th>订单号</th>
								  <th>联系方式</th>
								  <th>状态</th>
								  <th>操作</th>
                              </tr>
                              </thead>
                              <tbody id="klid">
                             
                              </tbody>
                          </table>	
</div>
<div id="klbtn">
</div>


</div>
</div>
</div> 
</div>
  
            
  </section>
   </section>

   <div class="modal fade" id="GoodsModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">编辑商品</h4>
            </div>
            <div class="modal-body" id="GoodsInfo">加载中...</div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
                <button type="button" class="btn btn-primary" id="EditGoods">提交更改</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal -->
</div>
   
   
   
<?php
include('foot.php');
?>
<script>
getKmlist();
</script>