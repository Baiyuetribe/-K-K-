<?php
/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496
 */
?>
<?php
include('../includes/common.php');
if($login_admin!=1){exit("<script language='javascript'>window.location.href='login.php';</script>");}
$title='网站信息配置';
include('head.php');
$webinfo=$database->get("config",["webname","webtitle","webkeywords","webdescription","qq","notice"]);
?>
 <section id="main-content">
          <section class="wrapper">
            
              <div class="row state-overview">
			  
                   <div class="col-sm-8 col-sm-offset-2">
                      <div class="panel panel-primary">
    <div class="panel-heading">
        <h3 class="panel-title"><font color="#ffffff"><h4>信息配置</h4></font></h3>
    </div>
    <div class="panel-body">
        
<form role="form">
  <div class="input-group">
            <span class="input-group-addon">网站名称</span>
            <input type="text" class="form-control" id="webname" name="webname" value="<?php echo $webinfo['webname'];?>">
        </div>
        <br>
	<div class="input-group">
            <span class="input-group-addon">标题</span>
            <input type="text" class="form-control" id="webtitle" name="webtitle" value="<?php echo $webinfo['webtitle'];?>">
        </div>
        <br>
		<div class="input-group">
            <span class="input-group-addon">关键字</span>
            <input type="text" class="form-control" id="webkeywords" name="webkeywords" value="<?php echo $webinfo['webkeywords'];?>">
        </div>
        <br>
		<div class="input-group">
            <span class="input-group-addon">描述</span>
            <input type="text" class="form-control" id="webdescription" name="webdescription" value="<?php echo $webinfo['webdescription'];?>">
        </div>
        <br>
		<div class="input-group">
            <span class="input-group-addon">客服QQ</span>
            <input type="text" class="form-control" id="qq" name="qq" value="<?php echo $webinfo['qq'];?>">
        </div>
        <br>
  	<div class="form-group">
    <label for="name">公告</label>
    <textarea class="form-control" rows="5" name="notice" id="notice"><?php echo $webinfo['notice'];?></textarea>
    </div>
   <button id="bcwebinfo" type="button" class="btn btn-info btn-block">确认保存</button>                               
</form>
		
    </div>
</div>
                     
                   </div> 
             </div>
  
            
  </section>
   </section>

<?php
include('foot.php');
?>