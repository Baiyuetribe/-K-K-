<?php
/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496
 */
?>
<?php
include('../includes/common.php');
if($login_admin!=1){exit("<script language='javascript'>window.location.href='login.php';</script>");}
$title='订单管理';
include('head.php');
?>
 <section id="main-content">
          <section class="wrapper">
            
              <div class="row state-overview">
			  
                   <div class="col-sm-8 col-sm-offset-2">
                      <div class="panel panel-primary">
    <div class="panel-heading">
        <h3 class="panel-title"><font color="#ffffff"><h4>订单列表</h4></font></h3>
    </div>
<div class="panel-body">
        
<div class="table-responsive">
	  <table class="table table-striped table-advance table-hover">
                              <thead>
                              <tr>
                                  <th>ID</th>
                                  <th>订单号</th>
								  <th>商品名称</th>
								  <th>交易金额</th>
								  <th>数量</th>
								  <th>创建/完成时间</th>
								  <th>联系方式</th>
								  <th>状态</th>
								  <th>操作</th>
                              </tr>
                              </thead>
                              <tbody id="olid">
                             
                              </tbody>
                          </table>	
</div>
<div id="olbtn">
</div>


</div>
</div>
</div> 
</div>
  
            
  </section>
   </section>

   
   
   
<?php
include('foot.php');
?>
<script>
getOrderlist();
</script>