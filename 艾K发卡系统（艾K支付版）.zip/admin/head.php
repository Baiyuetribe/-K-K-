<?php
if($login_admin!=1){exit("<script language='javascript'>window.location.href='login.php';</script>");}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <meta name="keyword" content="FlatLab, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
   
    <title><?php echo $title.'-'.$webname;?></title>

    <!-- Bootstrap core CSS -->
    <link href="../assets/admin/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/admin/css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="../assets/admin/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/admin/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen"/>
    <link rel="stylesheet" href="../assets/admin/css/owl.carousel.css" type="text/css">
    <!-- Custom styles for this template -->
    <link href="../assets/admin/css/style.css" rel="stylesheet">
    <link href="../assets/admin/css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="../assets/admin/js/html5shiv.js"></script>
      <script src="../assets/admin/js/respond.min.js"></script>
    <![endif]-->
	<style>
body
  {
  background-color:#E0E0E0;
  }
</style>
  </head>

  <body>
   <section id="container" class="">
      <!--header start-->
      <header class="header white-bg">
            <div class="sidebar-toggle-box">
                <div data-original-title="导航栏" data-placement="right" class="icon-reorder tooltips"></div>
            </div>
            <!--logo start-->
            <a href="http://www.aikpay.cn/" class="logo"><span>AiKpay.cn</span></a>
         
          
        </header>
      <!--header end-->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu">
                  <li class="active">
                      <a class="" href="index.php">
                          <i class="icon-dashboard"></i>
                          <span>后台首页</span>
                      </a>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon-tasks"></i>
                          <span>商品管理</span>
                          <span class="arrow"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="addgoods.php">添加商品</a></li>
                          <li><a class="" href="goodslist.php">商品列表</a></li>
                          <li><a class="" href="type.php">分类管理</a></li>
                      </ul>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon-list-alt"></i>
                          <span>卡密管理</span>
                          <span class="arrow"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="import.php">导入卡密</a></li>
                          <li><a class="" href="kmlist.php">卡密列表</a></li>
                      </ul>
                  </li>
                  <li>
                      <a class="" href="order.php">
                          <i class="icon-shopping-cart"></i>
                          <span>订单管理</span>
                       </a>
                  </li>
				  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon-cogs"></i>
                          <span>系统管理</span>
                          <span class="arrow"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="admin.php">管理员配置</a></li>
                          <li><a class="" href="webinfo.php">网站信息配置</a></li>
						   <li><a class="" href="pay.php">支付接口配置</a></li>
						   <li><a class="" href="http://www.aikpay.cn">艾K码支付</a></li>
                          <li><a class="" href="mail.php">邮箱配置</a></li>
						   <li><a class="" href="clean.php">数据清理</a></li>
                      </ul>
                  </li>
                  <li>
                      <a id="logout">
                          <i class="icon-user"></i>
                          <span>注销登录</span>
                      </a>
                  </li>
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
      <!--main content start-->