<?php
/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496
 */
?>
<?php
@header('Content-Type: application/json; charset=UTF-8');
date_default_timezone_set("PRC");
require_once("conn.php");
require_once('includes/360safe/webscan_cache.php');
require_once('includes/360safe/360webscan.php');
include "includes/function.php";
define('SYS_KEY', 'zyqq79520638');
$password_hash='!@#%!s!';
include "includes/member.php";

$act=isset($_GET['act'])?daddslashes($_GET['act']):null;
switch($act){
	case 'login':
	$name=daddslashes($_POST['name']);
	$pwd=daddslashes($_POST['pwd']);
	$check_login=$database->get("config",["password","username"],["username"=>$name,"password"=>$pwd]);
    if($check_login){
	    $session = md5($name.$pwd.$password_hash);
		$token = authcode("{$name}\t{$session}", 'ENCODE', SYS_KEY);
		setcookie("ylnfk_token", $token, time() + 3600*72,"/");
	    exit('{"code":0,"msg":"succ"}');
    }else{
        exit('{"code":-1,"msg":"账号或密码错误"}');
    }
	break;
	case 'getinfo':
	$types=$database->select("type","*");
    $goodss=$database->query("SELECT * FROM ylnfk_goods where goodsstate=1 order by goodssort+0 asc")->fetchAll();
	foreach($goodss as $goods)
    {
	 if(empty($goods['goodsimg'])){$goodsimg='assets/picture/noimage.jpg';}else{$goodsimg=$goods['goodsimg'];}
	 $kmnum0=$database->count("kms",["gid"=>$goods['gid'],"state"=>0]);
     $info.="<div class='mdui-card'><a href='buy.php?gid=".$goods['gid']."'><div class='mdui-card-header'><img class='mdui-card-header-avatar' src='".$goodsimg."'/><div class='mdui-card-header-title'>".$goods['goodsname']."</div><div class='mdui-card-header-subtitle'><span class='layui-badge'>单价：".$goods['goodsmoney']."元</span> <span class='layui-badge layui-bg-blue'>库存：".$kmnum0."</span></div></div></a></div><br>";
    }
	exit('{"code":0,"msg":"'.$info.'"}');
	break;
	case 'order':
	$gid=daddslashes($_POST['gid']);
	$num=daddslashes($_POST['num']);
	$contactway=daddslashes($_POST['contactway']);
	$type=daddslashes($_POST['type']);
	if(!preg_match("/^[1-9][0-9]*$/",$num)){ exit('{"code":-1,"msg":"非法数量"}');}
	$kmnum=$database->count("kms",["gid"=>$gid,"state"=>0]);
	if($num>$kmnum){ exit('{"code":-1,"msg":"库存不足"}');}
	$get=$database->get("goods",["goodsname","goodsmoney"],["gid"=>$gid]);
	if(!$get){ exit('{"code":-1,"msg":"商品不存在"}');}
	$order_number=date("YmdHis").mt_rand(100,999);
	$goodsname=$get['goodsname'];
	$money=$get['goodsmoney']*$num;
	$createtime=date("Y-m-d H:i:s");
	$add=$database->insert("order",["gid"=>$gid,"order_number"=>$order_number,"goodsname"=>$goodsname,"money"=>$money,"num"=>$num,"contactway"=>$contactway,"type"=>$type,"createtime"=>$createtime]);
	if($add){
        exit('{"code":0,"msg":"'.$order_number.'"}');
	}else{
		 exit('{"code":-1,"msg":"订单创建失败！"}');
	}
	break;
	case 'query':
	$category=daddslashes($_POST['category']);
	$content=daddslashes($_POST['content']);
	switch($category){
		case 'order_number':
		$getorder=$database->get("order","*",["order_number"=>"$content"]);
		if(!$getorder){exit('{"code":-1,"msg":"订单不存在！"}');}
		$kms=$database->select("kms",["km"],["order_number"=>"$content"]);
		foreach($kms as $km)
		{
		   $kminfo.="<font color='red'>".$km['km']."</font><br>";
		}
		$info="<tr><th>订单时间</th><td>".$getorder['createtime']."</td></tr><tr><th>订单号</th><td>".$getorder['order_number']."</td></tr><tr><th>支付状态</th><td>".getpaytate($getorder['status'])."</td></tr><tr><th>卡密信息</th><td>".$kminfo."</td></tr><tr><th>订单金额</th><td>".$getorder['money']."</td></tr>";
		exit('{"code":0,"msg":"'.$info.'"}');
		break;
		case 'contactway':
		$getorder=$database->select("order",["order_number","createtime"],["contactway"=>"$content"]);
		if(!$getorder){exit('{"code":-1,"msg":"暂无订单！"}');}
		foreach($getorder as $order)
		{ 
		    $info.="<tr><th><p>订单号：".$order['order_number']."</p><p>创建时间：".$order['createtime']."</p></th><td><a class='mdui-btn mdui-btn-icon mdui-btn-dense mdui-color-theme-accent mdui-ripple' href='?content=".$order['order_number']."'><i class='mdui-icon material-icons'>remove_red_eye</i></a></td></tr>";
		}
		exit('{"code":0,"msg":"'.$info.'"}');
	    break;
		default:
		exit('{"code":0,"msg":"系统错误"}');
		break;
	}
	break;
	default:
	exit('{"code":-2,"msg":"No Act"}');
    break;
}