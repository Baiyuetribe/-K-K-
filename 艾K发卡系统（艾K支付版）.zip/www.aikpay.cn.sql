-- MySQL dump 10.13  Distrib 5.6.37, for Linux (x86_64)
--
-- Host: localhost    Database: lhcc7n
-- ------------------------------------------------------
-- Server version	5.6.37-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ylnfk_config`
--

DROP TABLE IF EXISTS `ylnfk_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ylnfk_config` (
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `mail_host` varchar(32) NOT NULL DEFAULT 'smtp.qq.com',
  `mail_user` varchar(64) NOT NULL,
  `mail_key` varchar(64) NOT NULL,
  `webname` varchar(16) NOT NULL DEFAULT '忆流年发卡',
  `webtitle` varchar(32) NOT NULL DEFAULT '自动发卡',
  `webkeywords` varchar(32) NOT NULL DEFAULT '发卡，发卡网，提卡网，卡密',
  `webdescription` varchar(32) NOT NULL DEFAULT '全自动发卡系统',
  `qq` bigint(11) NOT NULL DEFAULT '79520638',
  `notice` text NOT NULL,
  `pay_host` varchar(32) NOT NULL,
  `pay_id` varchar(16) NOT NULL,
  `pay_key` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ylnfk_config`
--

LOCK TABLES `ylnfk_config` WRITE;
/*!40000 ALTER TABLE `ylnfk_config` DISABLE KEYS */;
INSERT INTO `ylnfk_config` VALUES ('admin','123456','smtp.qq.com','22814326@qq.com','www.aikpay.cn','艾K支付发卡网','自动发卡','发卡，发卡网，提卡网，卡密','全自动发卡系统',22814326,'<ul class=\"mdui-list\">\n  <li class=\"mdui-list-item mdui-ripple mdui-color-cyan\">艾K支付网：www.aikpay.cn</li>\n<li class=\"mdui-divider\"></li>\n  <li class=\"mdui-list-item mdui-ripple mdui-color-teal\">艾K支付支持码支付/易支付，全功能集成！</li>\n<li class=\"mdui-divider\"></li>\n  <li class=\"mdui-list-item mdui-ripple mdui-color-orange\">支持支付宝/QQ钱包/微信</li>\n</ul>\n<ul class=\"mdui-list\">\n  <li class=\"mdui-list-item mdui-ripple mdui-color-cyan\">艾K支付网：www.aikpay.cn</li>\n<li class=\"mdui-divider\"></li>\n  <li class=\"mdui-list-item mdui-ripple mdui-color-teal\">艾K支付支持码支付/易支付，全功能集成！</li>\n<li class=\"mdui-divider\"></li>\n  <li class=\"mdui-list-item mdui-ripple mdui-color-orange\">支持支付宝/QQ钱包/微信</li>\n</ul>','http://www.aikpay.cn/','www.aikpay.cn','aikpay.cn');
/*!40000 ALTER TABLE `ylnfk_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ylnfk_goods`
--

DROP TABLE IF EXISTS `ylnfk_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ylnfk_goods` (
  `gid` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(11) NOT NULL,
  `goodsname` varchar(32) NOT NULL,
  `goodsmoney` decimal(10,2) NOT NULL,
  `goodssort` int(11) NOT NULL,
  `goodsimg` varchar(255) NOT NULL,
  `goodspresent` varchar(255) NOT NULL,
  `goodsstate` int(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`gid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ylnfk_goods`
--

LOCK TABLES `ylnfk_goods` WRITE;
/*!40000 ALTER TABLE `ylnfk_goods` DISABLE KEYS */;
INSERT INTO `ylnfk_goods` VALUES (2,3,'艾K码/易支付www.aikpay.cn',0.01,1,'http://i2.bvimg.com/673893/313de829c7826ac8.png','艾K码/易支付www.aikpay.cn',1),(3,3,'艾K码/易支付www.aikpay.cn',0.01,2,'http://i2.bvimg.com/673893/313de829c7826ac8.png','艾K码/易支付www.aikpay.cn',1),(4,3,'艾K码/易支付www.aikpay.cn',0.01,3,'http://i2.bvimg.com/673893/313de829c7826ac8.png','艾K码/易支付www.aikpay.cn',1),(5,3,'艾K码/易支付www.aikpay.cn',0.01,4,'http://i2.bvimg.com/673893/313de829c7826ac8.png','艾K码/易支付www.aikpay.cn',1),(6,3,'艾K码/易支付www.aikpay.cn',0.01,5,'http://i2.bvimg.com/673893/313de829c7826ac8.png','艾K码/易支付www.aikpay.cn',1),(7,3,'艾K码/易支付www.aikpay.cn',0.01,6,'http://i2.bvimg.com/673893/313de829c7826ac8.png','艾K码/易支付www.aikpay.cn',1);
/*!40000 ALTER TABLE `ylnfk_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ylnfk_kms`
--

DROP TABLE IF EXISTS `ylnfk_kms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ylnfk_kms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gid` int(11) NOT NULL,
  `km` varchar(255) NOT NULL,
  `importtime` datetime NOT NULL,
  `selltime` datetime DEFAULT NULL,
  `contactway` varchar(32) DEFAULT NULL,
  `order_number` varchar(32) DEFAULT NULL,
  `state` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ylnfk_kms`
--

LOCK TABLES `ylnfk_kms` WRITE;
/*!40000 ALTER TABLE `ylnfk_kms` DISABLE KEYS */;
INSERT INTO `ylnfk_kms` VALUES (4,2,'测试','2019-01-22 12:30:14',NULL,NULL,NULL,0),(3,2,'测试','2019-01-22 12:30:14',NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `ylnfk_kms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ylnfk_order`
--

DROP TABLE IF EXISTS `ylnfk_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ylnfk_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gid` int(11) NOT NULL,
  `order_number` varchar(123) NOT NULL,
  `goodsname` varchar(32) NOT NULL,
  `money` decimal(10,2) NOT NULL,
  `num` int(11) NOT NULL,
  `contactway` varchar(32) NOT NULL,
  `type` varchar(10) NOT NULL,
  `createtime` datetime NOT NULL,
  `paytime` datetime DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ylnfk_order`
--

LOCK TABLES `ylnfk_order` WRITE;
/*!40000 ALTER TABLE `ylnfk_order` DISABLE KEYS */;
INSERT INTO `ylnfk_order` VALUES (4,2,'20190122123105767','艾K码/易支付www.aikpay.cn',0.01,1,'545545@qq.com','qqpay','2019-01-22 12:31:05',NULL,0),(3,2,'20190122123026730','艾K码/易支付www.aikpay.cn',0.01,1,'542424','wxpay','2019-01-22 12:30:26',NULL,0),(5,2,'20190122123236792','艾K码/易支付www.aikpay.cn',0.01,1,'415464','alipay','2019-01-22 12:32:36',NULL,0),(6,2,'20190122123244223','艾K码/易支付www.aikpay.cn',0.01,1,'45151@qq.com','wxpay','2019-01-22 12:32:44',NULL,0),(7,2,'20190122123536861','艾K码/易支付www.aikpay.cn',0.01,1,'424214','wxpay','2019-01-22 12:35:36',NULL,0),(8,2,'20190122123624433','艾K码/易支付www.aikpay.cn',0.01,1,'2525454javascript:void(0);','wxpay','2019-01-22 12:36:24',NULL,0),(9,2,'20190122123648357','艾K码/易支付www.aikpay.cn',0.01,1,'44174527452','qqpay','2019-01-22 12:36:48',NULL,0),(10,2,'20190122123723425','艾K码/易支付www.aikpay.cn',0.01,1,'5845415','alipay','2019-01-22 12:37:23',NULL,0);
/*!40000 ALTER TABLE `ylnfk_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ylnfk_type`
--

DROP TABLE IF EXISTS `ylnfk_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ylnfk_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `typename` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ylnfk_type`
--

LOCK TABLES `ylnfk_type` WRITE;
/*!40000 ALTER TABLE `ylnfk_type` DISABLE KEYS */;
INSERT INTO `ylnfk_type` VALUES (3,'艾K支付：www.aikpay.cn');
/*!40000 ALTER TABLE `ylnfk_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-01-22 12:43:47
