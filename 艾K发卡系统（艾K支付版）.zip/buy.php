<?php
/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496
 */
?>
<?php
@header('Content-Type: application/json; charset=UTF-8');
include('conn.php');
require_once('includes/360safe/webscan_cache.php');
require_once('includes/360safe/360webscan.php');
include "includes/function.php";
$gid=daddslashes($_GET['gid']);
$goodsinfo=$database->get("goods","*",["gid"=>$gid,"goodsstate"=>1]);
if(!$goodsinfo){
    exit("<script language='javascript'>window.location.href='index.php';</script>");
}
$kmnum=$database->count("kms",["gid"=>$gid,"state"=>0]);
if($kmnum<=0||empty($kmnum)){
	$kmnum='暂无库存';
}else{
	$kmnum=$kmnum;
}
$webinfo=$database->get("config",["webname","webtitle","webkeywords","webdescription","qq"]);
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="renderer" content="webkit"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <meta name="theme-color" content="#ffffff">
    <meta name="keywords" content="<?php echo $webinfo['webkeywords'];?>" />
    <meta name="description" content="<?php echo $webinfo['webdescription'];?>">
    <title><?php echo $webinfo['webname']; ?>-<?php echo $webinfo['webtitle']; ?></title>
    <link rel="stylesheet" href="assets/Mdui/css/mdui.min.css"/>
	<link rel="stylesheet" href="assets/layui/css/layui.css"  media="all">
<style>
body
  {
  background-color:#E0E0E0;
  }
</style>
  </head>
 <body class="mdui-drawer-body-left mdui-appbar-with-toolbar  mdui-theme-primary-indigo mdui-theme-accent-pink">
<header class="mdui-appbar mdui-appbar-fixed">
<div class="mdui-progress">
  <div class="mdui-progress-indeterminate"></div>
</div>
  <div class="mdui-toolbar mdui-color-theme">
    <a href="" class="mdui-typo-headline mdui-hidden-xs"><?php echo $webinfo['webname']; ?></a>
    <div class="mdui-toolbar-spacer"></div>
  </div>
</header>


<br>
<div class="mdui-container">
<div class="mdui-row">

<div class="mdui-col-md-6 mdui-col-offset-md-2";>

<div class="mdui-card">
  <div class="mdui-card-media">
	<img src=" <?php if(empty($goodsinfo['goodsimg'])){echo 'assets/picture/noimage.jpg';}else{echo $goodsinfo['goodsimg'];}?>" height="300"/>
    <div class="mdui-card-media-covered">
      <div class="mdui-card-primary">
        <div class="mdui-card-primary-title"><?php echo $goodsinfo['goodsname'];?></div>
      </div>
    </div>
  </div>
  <div class="mdui-card-actions">
   <span class="layui-badge-dot layui-bg-blue"></span>商品介绍
   <br>
   <h4><b><font color="#ff6699">
   <?php echo $goodsinfo['goodspresent'];?>
   </font></b></h4>
   <div class="mdui-divider"></div>
    <br>
    <span class="layui-badge-dot layui-bg-blue"></span>商品库存
	<span style="float:right;"><h4><b><font color="#ff6699"><?php echo $kmnum; ?></font></b></h4></span>
	<div class="mdui-divider"></div>
	 <br>
    <span class="layui-badge-dot layui-bg-blue"></span>商品单价
	<span style="float:right;"><h4><b><font color="#ff6699"><?php echo $goodsinfo['goodsmoney'];?></font></b><font color="#707070">元</font></h4></span>
	<div class="mdui-divider"></div>
  </div>
  
 <form class="layui-form layui-form-pane">
  <div class="layui-form-item">
    <label class="layui-form-label">数量</label>
    <div class="layui-input-block">
      <input type="text" name="num" id="num" autocomplete="off" placeholder="最低数量‘1’" value="1" class="layui-input">
    </div>
  </div>
  
  <div class="layui-form-item">
    <label class="layui-form-label">联系方式</label>
    <div class="layui-input-block">
      <input type="text" name="contactway" id="contactway" autocomplete="off" placeholder="推荐输入QQ邮箱" class="layui-input">
    </div>
  </div>
  </form>

<div class="mdui-bottom-nav mdui-bottom-nav-text-auto mdui-color-blue-grey">
  <a href="javascript:void(0);" class="mdui-ripple mdui-ripple-white mdui-bottom-nav-active" id="alipay">
    <img src="assets/picture/zfb.png" alt="" height="20" style="margin-top: 2px">
    <label>支付宝支付</label>
  </a>
   <a href="javascript:void(0);" class="mdui-ripple mdui-ripple-white mdui-bottom-nav-active" id="wxpay">
    <img src="assets/picture/wx.png" alt="" height="20" style="margin-top: 2px">
    <label></label>微信支付
  </a>
  <a href="javascript:void(0);" class="mdui-ripple mdui-ripple-white mdui-bottom-nav-active" id="qqpay">
    <img src="assets/picture/qq.png" alt="" height="20" style="margin-top: 2px">
    <label>QQ支付</label>
  </a>
</div>

</div>

</div>



</div>
</div>

<div class="mdui-container">
  <div class="mdui-fab-wrapper" id="fab">
    <button class="mdui-fab mdui-ripple mdui-color-pink-accent">
      <i class="mdui-icon material-icons">add</i>
      <i class="mdui-icon mdui-fab-opened material-icons">mode_edit</i>
    </button>
    <div class="mdui-fab-dial">
      <a class="mdui-fab mdui-fab-mini mdui-ripple mdui-color-red" href="query.php"><i class="mdui-icon material-icons">search</i>
      </a>
	  <a class="mdui-fab mdui-fab-mini mdui-ripple mdui-color-blue" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $webinfo['qq']; ?>&site=qq&menu=yes"><i class="mdui-icon material-icons">account_circle</i>
      </a>
      <a class="mdui-fab mdui-fab-mini mdui-ripple mdui-color-orang" href="index.php"><i class="mdui-icon material-icons">home</i>
      </a>
    </div>
  </div>
</div>

</div>




  <script src="assets/admin/js/jquery.js"></script>
  <script src="assets/Mdui/js/mdui.min.js"></script>
  <script src="assets/layui/layui.js" charset="utf-8"></script>
<script>
	layui.use(['layer'], function(){
	layer = layui.layer
	
	$("#alipay").click(function(){
	var goodsname= "<?php echo $goodsinfo['goodsname']; ?>"; 
	var goodsmoney= "<?php echo $goodsinfo['goodsmoney']; ?>";
	var kmnum= "<?php echo $kmnum; ?>";
	var gid= "<?php echo $gid; ?>";
	var num=$("input[name='num']").val();
	var goodsmoney= goodsmoney*num;
	var contactway=$("input[name='contactway']").val();
	if(kmnum=='暂无库存'){layer.msg('暂无库存！'); return false;}
	if(kmnum<num){layer.msg('库存不足！'); return false;}
	if(num=='' || contactway==''){layer.alert('数量和联系方式不能为空！', { skin: 'layui-layer-molv',closeBtn: 0});return false;}
	var info ="商品名称："+goodsname+"</br>购买数量："+num+"</br>联系方式："+contactway+"</br>支付金额："+goodsmoney+"</br>支付方式：支付宝";
	layer.confirm(info, {
	btn: ['创建订单','取消'] //按钮
	}, function(){
var index =layer.msg('正在创建订单', {icon: 16,shade: 0.01});
$.ajax({
    url:'ajax.php?act=order',
    data:{gid:gid,num:num,contactway:contactway,type:"alipay"},
    type:'post',
    dataType:'json',
    success:function(data){
	  layer.close(index);
	  if(data.code == 0){
		  layer.msg('创建成功,等待跳转', {icon: 6});
		   setTimeout(function(){
              window.location.href="other/epayapi.php?order_number="+data.msg+"";
            }, 2666);
	  }else{
      layer.msg(data.msg);
	  }
    },
    error:function(data){
	 layer.close(index);
	 layer.msg('服务器错误！');
    }
});
	});
	});
	
	$("#wxpay").click(function(){
	var goodsname= "<?php echo $goodsinfo['goodsname']; ?>"; 
	var goodsmoney= "<?php echo $goodsinfo['goodsmoney']; ?>";
	var kmnum= "<?php echo $kmnum; ?>";
	var gid= "<?php echo $gid; ?>";
	var num=$("input[name='num']").val();
	var goodsmoney= goodsmoney*num;
	var contactway=$("input[name='contactway']").val();
	if(kmnum=='暂无库存'){layer.msg('暂无库存！'); return false;}
	if(kmnum<num){layer.msg('库存不足！'); return false;}
	if(num=='' || contactway==''){layer.alert('数量和联系方式不能为空！', { skin: 'layui-layer-molv',closeBtn: 0});return false;}
	var info ="商品名称："+goodsname+"</br>购买数量："+num+"</br>联系方式："+contactway+"</br>支付金额："+goodsmoney+"</br>支付方式：微信支付";
	layer.confirm(info, {
	btn: ['创建订单','取消'] //按钮
	}, function(){
var index =layer.msg('正在创建订单', {icon: 16,shade: 0.01});
$.ajax({
    url:'ajax.php?act=order',
    data:{gid:gid,num:num,contactway:contactway,type:"wxpay"},
    type:'post',
    dataType:'json',
    success:function(data){
	  layer.close(index);
	  if(data.code == 0){
		   layer.msg('创建成功,等待跳转', {icon: 6});
		   setTimeout(function(){
               window.location.href="other/epayapi.php?order_number="+data.msg+"";
            }, 2666);
	  }else{
      layer.msg(data.msg);
	  }
    },
    error:function(data){
	 layer.close(index);
	 layer.msg('服务器错误！');
    }
});
	});
	});
	
	$("#qqpay").click(function(){
	var goodsname= "<?php echo $goodsinfo['goodsname']; ?>"; 
	var goodsmoney= "<?php echo $goodsinfo['goodsmoney']; ?>";
	var kmnum= "<?php echo $kmnum; ?>";
	var gid= "<?php echo $gid; ?>";
	var num=$("input[name='num']").val();
	var goodsmoney= goodsmoney*num;
	var contactway=$("input[name='contactway']").val();
	if(kmnum=='暂无库存'){layer.msg('暂无库存！'); return false;}
	if(kmnum<num){layer.msg('库存不足！'); return false;}
	if(num=='' || contactway==''){layer.alert('数量和联系方式不能为空！', { skin: 'layui-layer-molv',closeBtn: 0});return false;}
	var info ="商品名称："+goodsname+"</br>购买数量："+num+"</br>联系方式："+contactway+"</br>支付金额："+goodsmoney+"</br>支付方式：QQ钱包";
	layer.confirm(info, {
	btn: ['创建订单','取消'] //按钮
	}, function(){
var index =layer.msg('正在创建订单', {icon: 16,shade: 0.01});
$.ajax({
    url:'ajax.php?act=order',
    data:{gid:gid,num:num,contactway:contactway,type:"qqpay"},
    type:'post',
    dataType:'json',
    success:function(data){
	  layer.close(index);
	  if(data.code == 0){
		   layer.msg('创建成功,等待跳转', {icon: 6});
		   setTimeout(function(){
              window.location.href="other/epayapi.php?order_number="+data.msg+"";
            }, 2666);
	  }else{
      layer.msg(data.msg);
	  }
    },
    error:function(data){
	 layer.close(index);
	 layer.msg('服务器错误！');
    }
});
	});
	});
	
	
	});
	
var inst = new mdui.Fab('#fab');
// event
var fab = document.getElementById('fab');
fab.addEventListener('open.mdui.fab', function () {
  console.log('open');
});

fab.addEventListener('opened.mdui.fab', function () {
  console.log('opened');
});

fab.addEventListener('close.mdui.fab', function () {
  console.log('close');
});

fab.addEventListener('closed.mdui.fab', function () {
  console.log('closed');
});

</script>
  </body>
</html>