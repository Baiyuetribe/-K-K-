<?php
/* * 
 * 艾K码/易支付：www.aikpay.cn（欢迎对接）
 * 客服QQ：22814326/505114496
 */
?>
<?php
@header('Content-Type: application/json; charset=UTF-8');
require_once("conn.php");
require_once('includes/360safe/webscan_cache.php');
require_once('includes/360safe/360webscan.php');
$webinfo=$database->get("config",["webname","webtitle","webkeywords","webdescription","qq"]);
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="renderer" content="webkit"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <meta name="theme-color" content="#ffffff">
    <meta name="keywords" content="<?php echo $webinfo['webkeywords'];?>" />
    <meta name="description" content="<?php echo $webinfo['webdescription'];?>">
    <title><?php echo $webinfo['webname']; ?>-<?php echo $webinfo['webtitle']; ?></title>
    <link rel="stylesheet" href="assets/Mdui/css/mdui.min.css"/>
	<link rel="stylesheet" href="assets/layui/css/layui.css"  media="all">
<style>
body
  {
  background-color:#E0E0E0;
  }
</style>
  </head>
 <body class="mdui-drawer-body-left mdui-appbar-with-toolbar  mdui-theme-primary-indigo mdui-theme-accent-pink">
<header class="mdui-appbar mdui-appbar-fixed">
<div class="mdui-progress">
  <div class="mdui-progress-indeterminate"></div>
</div>
  <div class="mdui-toolbar mdui-color-theme">
    <a href="" class="mdui-typo-headline mdui-hidden-xs"><?php echo $webinfo['webname']; ?></a>
    <div class="mdui-toolbar-spacer"></div>
  </div>
</header>




<br>
<div class="mdui-container">
<div class="mdui-row">

<div class="mdui-col-md-8 mdui-col-offset-md-1";>

<div class="mdui-card">
  <div class="mdui-card-media">
   <form class="layui-form layui-form-pane">
   
    <div class="layui-form-item">
    <label class="layui-form-label">查询类别</label>
    <div class="layui-input-block">
      <select lay-filter="aihao" id="category" name="category">
        <option value="order_number">订单号</option>
        <option value="contactway">联系方式</option>
      </select>
    </div>
  </div>
  
      <input type="text" name="content" id="content" autocomplete="off" placeholder="请输入查询内容" value="<?php echo $_GET['content'];?>" class="layui-input">
   
    <button type="button" id="query"class="mdui-btn mdui-btn-block mdui-color-theme-accent mdui-ripple">查询订单信息</button>
  </form>
   
  </div>
  <div class="mdui-card-actions">
   <div class="mdui-table-fluid">
    <table class="mdui-table mdui-table-hoverable">
      <tbody id="queryinfo">
     
      </tbody>
    </table>
  </div>
  </div>
</div>

</div>



</div>
</div>

<div class="mdui-container">
  <div class="mdui-fab-wrapper" id="fab">
    <button class="mdui-fab mdui-ripple mdui-color-pink-accent">
      <i class="mdui-icon material-icons">add</i>
      <i class="mdui-icon mdui-fab-opened material-icons">mode_edit</i>
    </button>
   <div class="mdui-fab-dial">
      <a class="mdui-fab mdui-fab-mini mdui-ripple mdui-color-red" href="query.php"><i class="mdui-icon material-icons">search</i>
      </a>
	  <a class="mdui-fab mdui-fab-mini mdui-ripple mdui-color-blue" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $webinfo['qq']; ?>&site=qq&menu=yes"><i class="mdui-icon material-icons">account_circle</i>
      </a>
      <a class="mdui-fab mdui-fab-mini mdui-ripple mdui-color-orang" href="index.php"><i class="mdui-icon material-icons">home</i>
      </a>
    </div>
  </div>
</div>

</div>




  <script src="assets/admin/js/jquery.js"></script>
  <script src="assets/Mdui/js/mdui.min.js"></script>
  <script src="assets/layui/layui.js" charset="utf-8"></script>
<script>
layui.use(['layer','form'], function(){
	layer = layui.layer
	$("#query").click(function(){
		var index=layer.load(2);
		var category=$("select[name='category']").val();
		var content=$("input[name='content']").val();
$.ajax({
    url:'ajax.php?act=query',
    data:{category:category,content:content},
    type:'post',
    dataType:'json',
    success:function(data){
	  layer.close(index);
	  if(data.code == 0){
		   $("#queryinfo").html(data.msg);
	  }else{
      layer.msg(data.msg);
	  }
    },
    error:function(data){
	 layer.close(index);
	 layer.msg('服务器错误！');
    }
});
	
	});
	
});
var inst = new mdui.Fab('#fab');
// event
var fab = document.getElementById('fab');
fab.addEventListener('open.mdui.fab', function () {
  console.log('open');
});

fab.addEventListener('opened.mdui.fab', function () {
  console.log('opened');
});

fab.addEventListener('close.mdui.fab', function () {
  console.log('close');
});

fab.addEventListener('closed.mdui.fab', function () {
  console.log('closed');
});

</script>
  </body>
</html>